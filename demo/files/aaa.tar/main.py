###########################################################################
#
# Safe File Download / Upload Server
#
# Copyright (C) 2013-2017 Menlo Security. All rights reserved.
#
# A Tornado-based web server for fielding file download and upload
# requests. This service is independent of other subsystems mainly for
# performance isolation and horizontal scalability; IOW, to ensure that
# file transfer does not interfere with rendering operations, and to
# enable fine-grained MAC policies (e.g., via AppArmor/SELinux).
#
# Dependencies: the Tornado web server framework.
#
# ~~~~ Security ~~~~
#
# FIXME: This relies on the secrecy of the rid that downloaded the file. A
# better solution would check that the browser has a valid cookie for the
# browser id that downloaded the file. However, the browser id is not readily
# available here.
#
# ~~~~ Document Download Policy ~~~~
# During document upload to safedocs, a policy action has to be taken to
# either disable/enable original download. The file server queries PE through
# PNRHelper for the policy. Based on the response from PE the original version
# of the document is allowed/blocked. This operation happens asyncronously. In
# this way, the regular document upload operation is not modified. At the
# safedocs end, an AJAX poll is done to check if the download policy is
# available and finally enable/disable the orignal download of the file.
# This design was mainly chosen to retain user experience, the user can at
# least view the document before the virusscan is done. Currently, The
# fail open policy would be to allow the original version of the file.
#
# ~~~~ File Download Policy ~~~~
# If the file is not a document, then download policy has to be
# checked for the file. The SHA-256 of the file is calculated and the download
# policy is queried via PNRHelper. Based on policy, the download of the file
# is either allowed or blocked. Fail open policy will be to allow the download.
#
# ~~~~ NOTE ~~~~
# python-magic is used for file type introspection. check_file_type module
# wraps python-magic and checks the file type based on the metadata, file type
# string and also extension for some exceptional cases. Currently we isolate
# document files only so check_file_type will only detect the selected set of
# document types.
#
# ~~~~ Logging ~~~~
# Make sure that future logging messages conform to the logging conventions
# specified in the following wiki:
# http://trac.surfcrew.com/wiki/LoggingAndReporting
#
# vim:ts=3:sw=3:expandtab
#
###############################################################################
"""
   Safeview File Server
"""

from __future__ import division
from base64 import b64decode
from codecs import encode
import datetime
import hashlib
import json
import os
import os.path
import re
import shutil
import socket
import sys
import time
import urlparse
import uuid
import zlib

import concurrent.futures
import pytz
import tornado
import tornado.template

import _globals
from check_file_type import FileType, get_file_type_from_file
import plugins
import plugins_service
from plugins.result_codes import ResultCodes
from progress_store import ProgressStore
import runc_sandbox
from safly.app import SafelyTornadoApp, SafelyApplication
from safly.config import config
import safly.inotify
from safly.logger import get_logger
from safly.misc import www
import safly.os_util
import safly.plugin_manager
from safly.pnr_helper import PNRHelper
import safly.redis_client
from safly.servercall import PermissiveServerCallHandler,\
   ServerCallHandler
from safly.timex import monotonic
from safly.web import RequestHandler
from utils import working_directory, create_directory

log = get_logger("file-server")
# Reload sys and set default encoding to UTF-8 to avoid
# unicode decode errors
reload(sys)
# Module 'sys' has no 'setdefaultencoding' member
# pylint: disable=E1101
sys.setdefaultencoding('utf-8')


ALLOW = 'allow'
BLOCK = 'block'
CONTINUE = 'continue'
PENDING = 'pending'

SAFEDOC = 'safedoc'
SAFEVIEW = 'safeview'


# SHA256 hashing threadpool
# Hashing the file is CPU expensive, so we limit this to a single thread, and
# therefore it can only max out a single core. For reference (tested on a
# surrogate node 29Mar2017) a 3.5GB file hashed in about 15seconds.
MAX_HASHING_THREADS = 1
hashing_executor = concurrent.futures.ThreadPoolExecutor(
      max_workers=MAX_HASHING_THREADS)

# Action to plugin class mapping for file-server's plugins.
ACTION_PLUGIN_MAPPING = {
   'sleep': plugins.SleepPlugin,
   'error': plugins.ErrorPlugin,
   'scpexport': plugins.SCPPlugin,
   'av_scan': plugins.SophosPlugin,
   'sandbox': plugins.SophosSandboxPlugin,
   'fireeye_ax': plugins.FireEyeAXPlugin,
}

ARCHIVE_SCAN_CANDIDATE = [
   FileType.ZIP, FileType.GZIP, FileType.SEVENZIP,
   FileType.RAR, FileType.BZIP, FileType.CAB,
   FileType.ARJ, FileType.LZH, FileType.TAR
]

PASSWORD_PROMPT_CANDIDATE = [FileType.ZIP, FileType.RAR, FileType.SEVENZIP,
                             FileType.PDF]

# File Processing block to use when there is no policy but antivirus scanning
# is enabled by config.
DEFAULT_FILE_PROCESSING_BLOCK = {
   'plugin': 'av_scan',
   'always': 'true',
   'criticalpath': 'true',
   'config': {
      'on_error': 'block',
      'password_prompt': 'true',
      'time_out': config.getint('safefile', 'avengine_timeout')
   },
   'credentials': {}
}

# Password prompt limit
PASSWORD_PROMPT_RETRY_LIMIT = 3
PASSWORD_PROMPT_TIMEOUT_SEC = 180

# Shared dict for storing download policy state information.
policy_map = {}


def update_policy_map(download_key, value):
   if not policy_map.get(download_key):
      policy_map[download_key] = {
         'created_at': time.time()
      }
   policy_map[download_key]['icap_proxy_category_response'] = value

def del_expired_entries_from_policy_map():
   policy_map_entry_timeout = config.getint('file-server',
                                            'policy_map_entry_timeout')
   if not policy_map:
      return
   curr_time = time.time()
   for entry in list(policy_map):
      created_at = int(policy_map[entry]['created_at'])
      if (curr_time - created_at) > policy_map_entry_timeout:
         del policy_map[entry]


def result_code_to_outcome(plugin, result_code):
   """Temporary mapping of Plugin's result code to file processing outcome.

   Explicit 'allow' or 'block' will cause file processing to end the critical
   path at the point. 'continue' will cause file processing move onto the next
   step in the critical path.

   TODO: This should be provided by pnr-enforcement per plugin / tenant etc.
   """
   outcomes_by_plugin = {
      'sleep': {
         ResultCodes.RED: BLOCK,
         ResultCodes.AMBER: CONTINUE,
         ResultCodes.GREEN: CONTINUE,
         ResultCodes.UNKNOWN: CONTINUE,
         ResultCodes.PLUGIN_FAILED: CONTINUE,
      },
      'error': {
         ResultCodes.RED: BLOCK,
         ResultCodes.AMBER: CONTINUE,
         ResultCodes.GREEN: ALLOW,
         ResultCodes.UNKNOWN: CONTINUE,
         ResultCodes.PLUGIN_FAILED: CONTINUE,
      },
      'scpexport': {
         ResultCodes.GREEN: CONTINUE,
         ResultCodes.PLUGIN_FAILED: CONTINUE,
      },
      'av_scan': {
         ResultCodes.RED: BLOCK,
         ResultCodes.AMBER: CONTINUE,
         ResultCodes.GREEN: CONTINUE,
         ResultCodes.PLUGIN_FAILED: CONTINUE,
      },
      'sandbox': {
         ResultCodes.RED: BLOCK,
         ResultCodes.AMBER: CONTINUE,
         ResultCodes.GREEN: CONTINUE,
         ResultCodes.PLUGIN_FAILED: CONTINUE,
      },
      'fireeye_ax': {
         ResultCodes.RED: BLOCK,
         ResultCodes.AMBER: CONTINUE,
         ResultCodes.GREEN: CONTINUE,
         ResultCodes.PLUGIN_FAILED: CONTINUE,
      },
   }
   return outcomes_by_plugin[plugin][result_code]


def lookup_by_download_id(rid, download_id):
   """Returns filename and suggested filename.

   Given a request's @download_id and @rid, the fileserver's local path to the
   downloaded file is returned.
   """
   file_dir = os.path.join(config.get('surrogate', 'chroot_home'),
                           rid,
                           _globals.args.download_home.lstrip('/'))
   # Make sure there are no symlinks, '/../', etc. in the path
   if file_dir != os.path.normpath(file_dir):
      raise Exception('Invalid path component')
   metadata_file_path = os.path.join(file_dir, '%s.metadata' % int(download_id))
   filename = str(download_id)
   metadata = json.loads(open(metadata_file_path).read())
   # Suggest a filename that the client should use when saving the download.
   suggested_filename = get_suggested_filename(metadata['suggested_filename'])
   return os.path.join(file_dir, filename), suggested_filename, metadata


def get_suggested_filename(filename):
   """Returns the filename without the prepended @download_id

   for e.g. 1-download.pdf -> download.pdf
   """
   # Sanitize the filename
   # If the decoded_filename contains any slashes or .., then it is likely
   # to be attempting something bad. Therefore, instead of trying to
   # sanitize the complete filename to something sane, just get the first
   # basename and use that, or 'download' if it contains nothing useful.
   suggested_filename = os.path.basename(filename.encode('utf-8'))

   if any(x == suggested_filename for x in ('', '.', '..', '/')):
      suggested_filename = 'download'

   return suggested_filename


def get_sha256_sum(file_path, chunk_size=1024**2):
   """Compute sha256 from the local @file_path using 1MB chunk at a time"""
   try:
      hash_stream = hashlib.sha256()
      with open(file_path, 'rb') as file_stream:
         chunk = 0
         while chunk != b'':
            chunk = file_stream.read(chunk_size)
            hash_stream.update(chunk)
         return hash_stream.hexdigest()
   except Exception as ex:
      log.warning({'error': ex, 'local_filename': file_path},
                  event='sha256-sum-failed', opslog=True)
      raise


def can_safedocs(file_type):
   """Return boolean based on if file type can be sent to safedocs."""
   return file_type in [
      FileType.PDF, FileType.Word,
      FileType.PowerPoint, FileType.Excel,
      FileType.Ichitaro, FileType.RTF, FileType.Visio,
      FileType.OpenOfficeSpreadsheet,
      FileType.OpenOfficeText,
      FileType.OpenOfficePresentation]


def sanitize_src_uri(req_params, logger):
   """Remove data string from a data uri, replacing it with 'https://data-uri/"""
   try:
      # Assume any urls over 4kb are data-uris and should not be
      # considered to be a source url (as it's actually the file contents)
      if (len(req_params['src_uri']) >= 4096 or
          req_params['src_uri'].split('://')[0] not in ['http', 'https']):
         # FIXME Instead of rewriting as 'https://data-uri/',  sanitize_src_uri
         # should write the refer uri. Needs cooperation from TC to do this.
         req_params['src_uri'] = 'https://data-uri/'
   except Exception as ex:
      logger.warning(
         {
            'error': ex,
            'req_params': req_params
         },
         event='get-src-uri-failed',
         opslog=True)


@tornado.gen.coroutine
def get_pnr_policy(req_params, current_user, request, local_filename,
                   suggested_filename, file_type, logger,
                   proxy_category_result=None):
   """Determine the filetype and request the policy from PE.

   Return block, safedoc or safeview; along with the _nav_session_id.
   If PNRE is not enabled, return None for both policy and nav_session_id
   """
   if not config.getboolean('policy-enforcement-server', 'enabled'):
      raise tornado.gen.Return((None, None))

   pnr = PNRHelper()
   event = pnr.populate_event_data(
      req_params['src_uri'], current_user, request,
      nav_session_id=req_params.get('nav_session_id'))

   # Pass only the filename here and not the absolute path
   event['filename'] = suggested_filename
   event['file_type'] = file_type
   event['is_top_frame'] = True
   event['response_code'] = 200
   event['request_type'] = 'GET'
   event['x-safeview-fs-cache'] = event['_nav_session_id']
   event['x-menlo-category'] = proxy_category_result

   logger.debug({'filename': local_filename,
                 'suggested_filename': event['filename'],
                 'file_type': file_type},
                event='get-transfer-policy',
                opslog=False)

   response = yield tornado.gen.Task(
      pnr.post_request, '/api/v1/pe/response', event)

   log_dict = event.copy()
   log_dict.update(response)
   log_dict.pop('file_processing', None)
   log_dict.update({'filename': local_filename})
   logger.info(log_dict, event='transfer-policy-response', opslog=False)

   r = response.get('result')
   if r not in [BLOCK, SAFEDOC, SAFEVIEW]:
      # If we get an unexpected response from pnr-e, fail open
      logger.warning({'response': r},
                     event='unexpected-policy-response', opslog=False)
      r = SAFEVIEW
   raise tornado.gen.Return((r, event['_nav_session_id']))


class GetStatusMixIn(object):
   """Provides common status handling code for file downloads."""
   def _get_status(self, file_id, uid, tid):
      """Get the state from the progress store, and any extra data."""
      state = self.application.progress_store.get_file_state(file_id)
      resp = {'action': state}

      if state == self.application.progress_store.EXPIRED:
         return resp

      file_tid = self.application.progress_store.get_tenant_id(file_id)
      file_uid = self.application.progress_store.get_user_id(file_id)
      if (file_uid != uid or file_tid != tid):
         # File is in store, so check the user and tenant id is correct
         self.log.info({'file_id': file_id, 'state': state,
                        'file_owner_uid': file_uid,
                        'file_owner_tid': file_tid},
                       event='file-download-forbidden')
         raise self.forbidden('File status not allowed for user.')

      if state in [self.application.progress_store.SAFEDOC,
                   self.application.progress_store.SAFEDOC_PROCESSING]:
         # File has transferred to safedocs, add safedocs_url to redirect.
         resp['action'] = self.application.progress_store.SAFEDOC
         resp['url'] = (
            self.application.progress_store.get_file_safedocs_url(file_id))
      elif state == self.application.progress_store.PENDING:
         # File is still downloading, add sizes for UI.
         # 'content_length' can be None, and UI should then not display 'of x'
         resp['file_size'], resp['content_length'] = (
            self.application.progress_store.get_download_file_sizes(file_id))
      elif state == self.application.progress_store.PROCESSING:
         # File is processing, so provide status on progress for download UX
         resp['stage'], resp['total_stages'] = (
            self.application.progress_store.get_file_analysis_stage(file_id))

      return resp


class ICAPStatusHandler(GetStatusMixIn, RequestHandler):
   """Handle file processing status requests from the icap-server."""
   # TODO: This should only be available on the internal HAProxy routes
   # pylint: disable=arguments-differ
   def post(self, file_id):
      # Check the api-secret is valid.
      if (self.request.headers['x-api-secret'] !=
          config.get('file-server', 'icap_fs_secret')):
         raise self.forbidden('Unauthorized access.')

      user_info = json.loads(b64decode(self.request.headers['x-api-property']))
      uid = user_info['uid']
      tid = user_info['tid']

      response = self._get_status(file_id, uid, tid)
      self.log.debug({'id': file_id,
                      'state': response['action']},
                     event='icap-status-request', opslog=False)
      self._disable_client_caching()
      self.write(response)
      self.finish()


class TCStatusHandler(GetStatusMixIn, PermissiveServerCallHandler):
   """Handle file processing status requests from tc."""
   def on_auth_success(self):
      # TODO: Remove the use of the rid from this file and the TC requests.
      # See SV-3090.
      user_info = self.get_current_user()
      uid = user_info['uid']
      tid = user_info['tid']
      file_id = self._req_params['file_id']

      response = self._get_status(file_id, uid, tid)
      self.log.debug({'id': file_id,
                      'state': response['action']},
                     event='tc-status-request', opslog=False)
      self.finish_with_json(response)


class DLPageStatusHandler(GetStatusMixIn, ServerCallHandler):
   """Handle file processing status requests from ICAP download page.

   This class is similar to TCStatusHandler, however it does not allow
   CORS, and its GET method will return the polling element of the ICAP
   download page.

   When dealing with the download page, extra care needs to be taken, as the
   client could switch region (ie eu-west-1 to us-east-1) at any point after
   login. If this happens, the new region's domains will not be cookied (as
   login will have only cookied eu-west-1's). Unless the client navigates to
   a new isolated website, and therefore trigger the cookie install within
   surrogate-router, they will remain missing.

   The net result is that status requests from the download page to the
   file-server will fail if a non-isolated proxy-routed file download is
   requested.

   To assist with this, the polling element of the download page (provided
   by this API) will attempt a reauthentication and a subsequent re-cookie
   of the cluster host.

   A full redirect is not possible as the download page is shown primarily
   to keep the connection between the client and upstream server alive, and
   allows file-server to receive the file. If a page level redirect is
   performed, the download will be interrupted, and fail.
   """
   def _set_csp(self):
      """Set the CSP for the GET response.

      CSP will disallow all but style and scripts being loaded from the
      same origin, and prevent inline scripts.
      """
      cluster_host = self.domain_scheme.get_cluster_host()
      xhr_cluster_host = self.domain_scheme.get_cluster_host(('xhr', 0))
      login_host = self.domain_scheme.get_login_host()
      csp = ("default-src 'none'; "
             "script-src 'self' https://%(safeview_static)s; "
             "style-src 'self' https://%(safeview_static)s; "
             "connect-src 'self' %(cookied_domains)s; "
             "report-uri /safeview-client-logger/csp-violation;"
             % {'safeview_static': cluster_host,
                'cookied_domains': ' '.join(
                  ['https://' + d for d in
                   [xhr_cluster_host, cluster_host, login_host]])})

      self.set_header('Content-Security-Policy', csp)

   @tornado.gen.coroutine
   def get(self):
      """GET will return the polling element of the download page.

      The single_use_code for the file_id is used by the client to provide
      a level of verification that they are the correct party to get the
      download status page.

      As before, access to the file and its status is still restricted to the
      correct user / tid, and will require the safeview cookie to authenticate.
      """
      self._disable_client_caching()

      try:
         # The query argument names are deliberately obfuscated to a and b
         file_id = self.get_query_argument('a')
         single_use_code = self.get_query_argument('b')

      except tornado.web.MissingArgumentError as e:
         # Cannot let the exception bubble, as it will render a safly
         # style error page. This will fill the iframe and prevent the
         # parent's message from updating to error, which is a more UX
         # friendly outcome.
         self.log.error({'url': self.request.uri,
                         'missing_argument': e.arg_name},
                        event='dlpage-required-argument-missing')
         self.set_status(400)
         self.write('')
         self.finish()
         return

      # Cross check the single_use_code is valid, as we may not have the
      # cookie to validate the file belongs to the requesting user
      if not self.application.progress_store.check_single_use_code(
            file_id, single_use_code):
         # The token didn't match, so return a 403 forbidden.
         self.log.warning({'file_id': file_id},
                          event='status-page-invalid-code-used')
         raise self.forbidden('Invalid token for status page.')

      # The single_use_code is valid, so grab the filename from the progress
      # store, and return the templated iframe content
      self._set_csp()
      self.render(
         www('templates/icap_status_iframe.template'),
         file_name=self.application.progress_store.get_file_path_and_name(
            file_id)[1])
      self.log.debug({'file_id': file_id},
                     event='dlpage-requested')

   def on_auth_failure(self, *args, **kwargs):
      """Log the authentication failure.

      This could be due to a missing cookie, in which case the returned 403
      and the inclusion of the login_host will trigger a re-cookie by the
      download page.
      """
      file_id = self._req_params.get('file_id', 'no-file-id')
      self.log.debug({'file_id': file_id},
                     event='dl-status-request-failed')
      self.set_status(403)
      self.finish_with_json(
         {'login_host': self.domain_scheme.get_login_host()})

   def on_auth_success(self, *args, **kwargs):
      """Return the processing status of the file_id."""
      user_info = self.get_current_user()
      uid = user_info['uid']
      tid = user_info['tid']
      file_id = self._req_params['file_id']

      response = self._get_status(file_id, uid, tid)
      self.log.debug({'id': file_id,
                      'state': response['action']},
                     event='dl-status-request', opslog=False)
      self.finish_with_json(response)

   def get_ok_origins(self):
      return self.domain_scheme.get_ok_origins()


class SurrogateStatusHandler(GetStatusMixIn, RequestHandler):
   """Handle file processing status requests from the surrogate for uploads."""
   def post(self):
      body_params = tornado.escape.json_decode(self.request.body or '{}')
      uid = body_params['uid']
      tid = body_params['tid']
      file_id = body_params['file_id']

      response = self._get_status(file_id, uid, tid)

      self.log.debug({'id': file_id,
                      'state': response['action']},
                     event='surrogate-status-request', opslog=False)

      # There is no UI to report information states, so for the surrogate
      # the API is simplied. 'action' will return only 'allow', 'block', or
      # 'processing', with unexpected and error states failing closed to
      # 'block'.
      if not response['action'] in ['allow', 'block', 'processing']:
         response = {'action': 'block'}

      self._disable_client_caching()
      self.write(response)
      self.finish()


class DownloadHandler(RequestHandler):
   """Handles file download requests.

   SEND_HEADERS can be set False to prevent the automatic sending of any
   headers. This is needed if the client to this API is attempting to
   proxy the download, and is interpreting the headers directly, and eg
   decompressing, instead of purely proxying the data stream.
   """
   SEND_HEADERS = True

   def _write_all_chunks(self, chunk_size=4096):
      """Streams file contents out to client, one chunk at a time."""
      chunk = self._file.read(chunk_size)
      if not chunk:
         self.finish()
         self._file.close()
         self._file = None
         return
      self.write(chunk)
      self.flush(callback=self._write_all_chunks)

   def has_alternate_auth(self):
      """Override to provide an alternate authentication method.

      Return a dictionary with uid and tid keys, or None if not authenticated.
      """
      return None

   # pylint: disable=too-many-branches
   @tornado.web.asynchronous  # to enable concurrent downloads
   def get(self, file_id):
      # method gets one argument based on handler regex - OK to disable
      # warning.
      #
      # pylint: disable=arguments-differ
      self.file_id = file_id

      user_info = self.get_current_user()
      if not user_info:
         user_info = self.has_alternate_auth()
      if not user_info:
         raise self.forbidden('Unauthorized user.')

      uid = user_info['uid']
      tid = user_info['tid']

      if (self.application.progress_store.get_file_state(file_id) ==
          self.application.progress_store.EXPIRED):
         # Check file is in the progress store...
         raise self.notfound('File not found in progress store.')

      elif (self.application.progress_store.get_user_id(file_id) != uid or
            self.application.progress_store.get_tenant_id(file_id) != tid):
         # ... file is in store, so check the user and tenant id is correct...
         raise self.forbidden('File download not allowed for user.')

      elif (self.application.progress_store.get_file_state(file_id) !=
            ALLOW or not self.application.progress_store.is_download(file_id)):
         # Catch attempt to subvert download before file state is 'allow',
         # or if download is requested for a file being uploaded. Both of
         # these cases should not happen.
         raise self.forbidden('File download not allowed.')

      original_headers = (
         self.application.progress_store.get_original_headers(file_id))

      try:
         local_filename, suggested_filename = (
            self.application.progress_store.get_file_path_and_name(
               file_id, compressed='content-encoding' in original_headers))
         file_type, mime_type = self.application.progress_store.get_file_type(
            file_id)
      except KeyError:
         # Does not exist in the progress_store.
         local_filename, suggested_filename, file_type = (None, None, None)

      if local_filename and os.path.exists(local_filename):
         self.log.increment('file-downloads-direct')
         self.log.info({'file_id': file_id,
                        'file_type': file_type,
                        'local_filename': local_filename,
                        'suggested_filename': suggested_filename},
                       event='file-download-direct', opslog=False)
         self._disable_client_caching()

         if self.SEND_HEADERS:
            # Set the headers, using originals where possible.
            if "content-encoding" in original_headers:
               self.set_header(
                  "Content-Encoding", original_headers['content-encoding'][0])

            if "content-type" in original_headers:
               self.set_header(
                  "Content-Type", original_headers['content-type'][0])
            elif file_type == FileType.PDF:
               self.set_header("Content-Type", "application/pdf")
            elif mime_type:
               self.set_header("Content-Type", mime_type)
            else:
               self.set_header("Content-Type", "application/octet-stream")

            # If we have the original content disposition, use that
            if "content-disposition" in original_headers:
               self.set_header("Content-Disposition",
                               original_headers['content-disposition'][0])
            else:
               # If this is a 'document' type that could have gone to safedocs
               # but was set to 'allow' native download, then try to get the
               # client browser to open this inline (e.g. using pdf.js), else
               # get the browser to save this to disk.
               if can_safedocs(file_type):
                  content_disposition = 'inline'
               else:
                  content_disposition = 'attachment'
               self.set_header("Content-Disposition", '%s; filename=\"%s\"' %
                               (content_disposition, suggested_filename))

         self._file = open(local_filename, 'r')
         self.application.progress_store.set_first_file_download_time(file_id)

         self._write_all_chunks()
      else:
         # Catch the case where the file does not exist.
         self.log.warning({'file_id': file_id,
                           'local_filename': local_filename,
                           'suggested_filename': suggested_filename},
                          event='file-download-not-exist', opslog=False)
         raise self.notfound('File does not exist.')


class ArchDownloadHandler(RequestHandler):
   def send_file(self, file_path, chunk_size=4096):
      """Streams file contents out to client, one chunk at a time."""
      file_obj = open(file_path, 'r')
      chunk = file_obj.read(chunk_size)
      while chunk:
         self.write(chunk)
         chunk = file_obj.read(chunk_size)
      file_obj.close()

   @tornado.gen.coroutine
   def extract(self, safedoc_file, sub_file, work_dir, enc):
      """Unzip the sub_file from the original file, and return the path"""
      ori_file_name = enc.get('zip_list', {}).get('file_name', 'original_file')
      ori_file_path = os.path.join(work_dir, ori_file_name)
      os.link(safedoc_file, ori_file_path)
      self.log.debug({'ori_file_path': ori_file_path,
                      'sub_file': sub_file,
                      'safedoc_file': safedoc_file,
                      'work_dir': work_dir,
                      'enc': enc})
      cid = str(uuid.uuid4())
      try:
         runc_work_dir = os.path.join(work_dir, 'decryption')
         container_result = yield runc_sandbox.execute_async(
            {'cmd': 'create_container',
             'container_id': cid,
             'input_dir': work_dir,
             'work_dir': runc_work_dir,
             'uid': os.getuid(), 'gid': os.getgid()})

         if not container_result.get('result'):
            raise Exception('Failed to create container')
         # Unzip the file
         unzip_result = yield runc_sandbox.execute_async(
            {'cmd': 'unzip',
             'file_path': '/safefile-input',
             'file_name': ori_file_name,
             'target_file': sub_file,
             'password': enc.get('password', ''),
             'container_id': cid})
         if not unzip_result.get('result'):
            raise Exception('Failed to unzip the target file: %s' % sub_file)
         unzipped_file = unzip_result.get('path').replace(
            runc_sandbox.WORK_PATH,
            runc_work_dir)
         self.log.debug({'ori_file_name': ori_file_name,
                         'target_file': sub_file,
                         'password': enc.get('password', ''),
                         'unzip_result': unzip_result,
                         'unzipped_file': unzipped_file},
                        event='unzip-succeeded')
         if not os.path.exists(unzipped_file):
            raise Exception('Failed to find unzipped file')
         raise tornado.gen.Return(unzipped_file)
      finally:
         yield runc_sandbox.execute_async(
            {'cmd': 'delete_container',
             'container_id': cid})

   @tornado.gen.coroutine
   def get(self, doc_id, file_index):
      """Unzip the target file from the archive file, and send back the file
      to the request sender.
      """
      # pylint: disable=arguments-differ
      self.file_id = doc_id.split('-')[1]
      self.file_index = int(file_index)
      # TODO: Check user ID and tenent ID if possible. For now we cannot get
      # the user ID from the request because the surrogate browser does not
      # attach it.
      self.ps = self.application.progress_store
      if (self.ps.get_file_state(self.file_id) == self.ps.EXPIRED):
         # Check file is in the progress store...
         raise self.notfound('File not found in progress store.')
      try:
         # Check if the file is in Safedocs storage
         file_path = '%s/tmpdocs/%s/document' % (config.get('docview',
                                                            'document_folder'),
                                                 doc_id)
         if not os.path.exists(file_path):
            raise self.notfound('The original file is not found.')
         enc = self.ps.get_encryption_detail(self.file_id)
         if not enc or not enc.get('zip_list'):
            raise self.notfound('Failed to get the encrypton information.')
         if len(enc['zip_list'].get('files', [])) <= self.file_index:
            raise self.forbidden('Wrong subfile index.')
         if enc.get('encrypted', False) and not enc.get('password'):
            raise self.forbidden('Cannot unzip the subfile.')
         sub_file = enc['zip_list']['files'][self.file_index]['Path']
         # Start extracting the file
         with working_directory() as work_dir:
            extracted_file = yield self.extract(file_path, sub_file,
                                                work_dir, enc)
            if not os.path.exists(extracted_file):
               raise Exception('File does not exist!')
            self.set_header("Content-Disposition", '%s; filename=\"%s\"' %
                            ('attachment', os.path.basename(extracted_file)))
            yield self.application.executor.submit(self.send_file,
                                                   extracted_file)
            self.finish()
      except Exception as e:
         self.log.error({'file_id': self.file_id,
                         'file_index': self.file_index,
                         'error': str(e)},
                        event='failed-to-download-file-in-archive')
         raise self.forbidden('File download not allowed.')

class ICAPDownloadHandler(DownloadHandler):
   """Handles file download requests from icap server using a single use key.

   When a file is uploaded to the file-server, a single use key can be
   requested that will allow a one time download of the file back from the
   file-server.

   This is required for providing native downloads on the non-isolated
   proxy route. Due to the lack of trust between the proxy node and the
   safeview nodes, icap server is prevented from using an internal only
   HAProxy route. There may also be no SV cookie to use to authenticate.
   Ultimately there is no un-authenticated route to retrieve the file.

   This single use key allows the icap <-> file-server to have a one-time
   authentication. icap_server can upload a file to file-server for processing
   and then redownload and stream the file to the client for a native download
   using the single use key it was provided. Once a file is requested using
   this API, regardless of the success of authentication, the key is destroyed.
   This aims to prevent a brute force style attack trying to guess the access
   code if the file's URL is obtained.

   If the file received was compressed, this handler needs to the return the
   compressed version to give as "native" an experience as possible.

   In all cases, the finish() method of the request can be used to trigger a
   cleanup of the entire working directory.

   TODO: Remove this access path when it is no longer needed.
   """
   SEND_HEADERS = False

   def has_alternate_auth(self):
      """Allow the use of a single use authentication code.

      Return True if the code is a match. Side-effect of this API call is the
      destruction of a file's single_use_code even if there is no match.

      Also checks to ensure the api secret is correct for icap <-> fs APIs
      """
      # Check the api-secret is valid.
      if (self.request.headers['x-api-secret'] !=
          config.get('file-server', 'icap_fs_secret')):
         self.log.warning({'file_id': self.file_id},
                          event='invalid-api-secret')
         return None

      single_use_code = b64decode(self.request.headers['x-access-code'])
      if self.application.progress_store.check_single_use_code(
            self.file_id, single_use_code):
         return json.loads(b64decode(self.request.headers['x-api-property']))
      else:
         self.log.warning({'file_id': self.file_id},
                          event='invalid-access-code-used')
         return None

   def finish(self):
      super(ICAPDownloadHandler, self).finish()
      self.application.progress_store.remove_file_id(self.file_id)

class ICAPInboundHandler(RequestHandler):
   """Handler to "pair" a file download to an available file-server.

   Performs a simple space check to determine if this node can accept the file,
   before returning the node_id (for embedding into the download page in icap
   for sticky routing) and a generated file_id (also embedded into the download
   page). The file_id is used to identify the file transfer in all future
   requests from ICAP or the download page. Also contained within this request
   is a chunk of metadata about the file that should be stored in the progress
   store. Additional meta_data will be received in the ICAP transfer.

   TODO: All meta_data should come through the inbound_hander and be referenced
   from the progress_store - too much downsteam reliance on _req_params to do
   this at the moment.

   This request needs to be separate from the transfer so this information can
   be embedded and the download page served to the client. The transfer can
   then be streamed from icap to file-server, with progress available to the
   user.

   Due to this separation, the space check is therefore not a guarantee and of
   course the subsequent transfer request could occur at a point where space is
   no longer available. This is mitigated by HAProxy using round-robin to
   distribute these requests to all possible file-servers in the deployment. If
   space is no longer available when the transfer begins, the file_id state is
   updated to ERROR and the file download page should inform the user to retry.
   """
   def __init__(self, *args, **kwargs):
      super(ICAPInboundHandler, self).__init__(*args, **kwargs)
      self._req_params = {}

   def post(self):
      # Check the api-secret is valid.
      if (self.request.headers['x-api-secret'] !=
          config.get('file-server', 'icap_fs_secret')):
         raise self.forbidden('Unauthorized access.')

      # Decode meta-data about the file to be used by the request
      self._req_params = tornado.escape.json_decode(
         self.request.body or '{}')

      node_id = config.get('instance-metadata', 'node_id')
      log_data = {'file_name': self._req_params['file_name'],
                  'user_id': self._req_params['user_id'],
                  'tenant_id': self._req_params['tenant_id'],
                  'node_id': node_id}

      if not self.application.space_available():
         # Not enough space remaining.
         self.log.warning(log_data,
                          event='inbound-insufficient-disk-space')
         raise tornado.web.HTTPError(status_code=503)

      # Create entry in the progress_store. A storage directory for the
      # lifetime of the file is also created by this insertion.
      file_id = self.application.progress_store.insert_file_icap(
         self._req_params['file_name'],
         self._req_params['user_id'], self._req_params['tenant_id'],
         self._req_params['file_size'])

      # Store the headers of the original download request
      self.application.progress_store.set_original_headers(
         file_id, self._req_params['original_headers'])

      # Store the src_uri of the original download request
      self.application.progress_store.set_src_uri(
         file_id, self._req_params['src_uri'])

      # Store PNR's analytics object for later use
      self.application.progress_store.set_analytics(
         file_id, self._req_params['analytics'])

      # Create the single_use_code - don't log it!
      code = self.application.progress_store.create_single_use_code(file_id)

      log_data['file_id'] = file_id
      self.log.info(log_data, event='icap-transfer-inbound', opslog=False)

      self._disable_client_caching()
      self.write({'file_id': file_id, 'node_id': node_id,
                  'single_use_code': code})
      self.finish()


class AddForensicChecks(object):
   """Adds AV checks to a handler classes as a Mixin."""

   @tornado.gen.coroutine
   def set_transaction_result(self, av_response):
      """Set the result for original and safe download outcome.

      Update the progress_store based on the result. If docid is present,
      a POST to safedocs of the outcome is also required.
      """
      if self.docid:
         yield self._set_safedoc_download_policy(
            av_response['transfer_safe'], av_response['transfer_original'],
            av_response['av_scan_result'], av_response['virus_details'])
         self.application.progress_store.set_file_safedoc(self.file_id)
      else:
         # Update the progress_store
         if av_response['transfer_original'] == BLOCK:
            self.application.progress_store.set_file_block(self.file_id)
         else:
            self.application.progress_store.set_file_allow(self.file_id)

   def enforce_request_completness(self, query_keys, body_keys=None):
      """Ensure that all the API parameters are present

      The presence of all the required parameters is enforced. Returns False.
      In the event that any are absent. Any Query parameters are added to the
      _req_params dictionary.
      """
      try:
         for key in query_keys:
            self._req_params[key] = self.get_argument(key)

         av_keys = {'src_uri'}.union(body_keys or {})
         if not set(self._req_params.keys()).issuperset(av_keys):
            raise KeyError('Missing argument')

         sanitize_src_uri(self._req_params, self.log)
         return True

      except Exception as ex:
         self.log.info(
            {
               'query_keys': query_keys,
               'body_keys': body_keys,
               'req_params': self._req_params,
               'error': ex
            },
            event='file-upload-api-params-absent',
            opslog=False)
         return False

   @tornado.gen.coroutine
   def do_avcheck(self, policy, src_uri, local_filename, cache_key,
                  analytics=None, file_type=None):
      """Send avcheck request.

      Invokes avcheck to request a virustotal check for the given file
      hash, and respond with the decision to allow / block the original
      and safe pdf downloads based on policy.

      To handle the initial pnr-e request being performed on the proxy
      node, and the subsequent avcheck on the surrogate, the analytics
      cached by the initial request needs to be passed from the proxy
      node to the local pnr-e. This is acheived through the 'analytics'
      arument of this function.
      """
      pnr = PNRHelper()
      event = pnr.populate_event_data(
         src_uri, self.get_current_user(), self.request, cache_key)

      # TODO: For ICAP transfers, move the file hashing out so it can be
      # compared with the value logged by the ICAP server.
      file_hash = yield hashing_executor.submit(get_sha256_sum, local_filename)

      event['sha256'] = file_hash
      event['cache_key'] = cache_key
      event['direction'] = self.DIRECTION
      if analytics:
         event['analyticsData'] = analytics
      if file_type:
         event['file_type'] = file_type
      if 'user_agent' in self._req_params:
         event['user_agent'] = self._req_params['user_agent']

      start_time = monotonic()

      response = yield tornado.gen.Task(
         pnr.post_request, '/api/v1/pe/avcheck', event)

      time_taken = monotonic() - start_time
      self.log.timer('file-process-hashcheck', time_taken)

      log_dict = event.copy()
      log_dict.update(response)
      log_dict.pop('file_processing', None)
      log_dict.pop('analyticsData', None)
      if response.get('file_processing'):
         log_dict.update({'plugins_list': [plugin.get('plugin') for plugin
                                           in response['file_processing']]})
      self.log.info(log_dict, event='avcheck-response', opslog=False)

      # if download policy is other than 'block', allow it
      # Allow even if policy is an empty string for fail open.
      transfer_original = BLOCK \
         if BLOCK in [policy, response.get('download_original', '')] \
         else ALLOW
      # If avcheck returned 'Unknown', this will be the actionOnUnknown result
      action_on_unknown = transfer_original
      av_scan_result = response.get('av_scan_result', '')
      if av_scan_result:
         self.log.increment('plugin-run-hashcheck')
      if av_scan_result == 'Unknown':
         self.log.increment('plugin-result-hashcheck-unknown')
      elif av_scan_result == 'Infected':
         self.log.increment('plugin-result-hashcheck-infected')
      elif av_scan_result == 'Clean':
         self.log.increment('plugin-result-hashcheck-not-infected')
      else:
         self.log.increment('plugin-result-hashcheck-skipped')

      # If this is a file upload and the hash is unknown to VT, allow it
      if self.DIRECTION == ProgressStore.UPLOAD and av_scan_result == 'Unknown':
         transfer_original = ALLOW

      transfer_safe = BLOCK \
         if BLOCK in [response.get('download_safe', '')] \
         else ALLOW
      self.log.increment('file-transfer-pe-%s' % transfer_original)

      raise tornado.gen.Return({
         'transfer_original': transfer_original,
         'transfer_safe': transfer_safe,
         'file_processing_list': response.get('file_processing', []),
         'category': response.get('category'),
         'av_scan_result': response.get('av_scan_result'),
         'virus_details': response.get('virus_details', []),
         'av_vendors': response.get('av_vendors', []),
         'file_hash': file_hash,
         'action_on_unknown': action_on_unknown,
         'action_on_malware': response.get('action_on_malware', BLOCK)
      })

   def prepare_file(self, original_file, working_file):
      """Perform an action to locate the file at working_file.

      This gets the file ready to be used in the working directory.
      This function is submitted to the threadpool to run so can block.

      Default implementation is to hardlink the file.
      """
      self.log.debug({'original_file': original_file,
                      'working_file': working_file},
                     event='prepare-file')
      os.link(original_file, working_file)

   @tornado.gen.coroutine
   def _action_processing_list(self, file_info, av_response):
      """Iterate the processing actions and monitor the response.

      Actual method call returns a Future which will resolve to contain
      a ResultCode integer.
      """
      self.log.debug({'filename': file_info['local_filename'],
                      'processing_list': av_response['file_processing_list']},
                     event='file-processing-list', opslog=False)

      user_info = self.get_current_user()
      uid = user_info['uid']
      tid = user_info['tid']

      # system_config.timezone can be empty if a specific TZ has not
      # been specified. In this case default to GMT.
      timezone_str = config.get('system_config', 'timezone')
      if timezone_str not in pytz.all_timezones:
         if timezone_str != '':
            # If the string wasn't empty, something unexpected made it
            # into the config. The dashboard validates the specified TZ
            # is valid before writing to the file, so this should not happen!
            self.log.warning({'timezone': timezone_str},
                             event='invalid-timezone-detected',
                             opslog=True)
         timezone_str = 'Etc/GMT'
      timezone = pytz.timezone(timezone_str)

      meta_data = {'filename': file_info['suggested_filename'],
                   'file_type': file_info['file_type'],
                   'src_uri': self.src_uri,
                   'direction': self.DIRECTION,
                   'file_hash': av_response['file_hash'],
                   'category': av_response['category'],
                   'hostname': socket.gethostname(),
                   'node_id': config.get('instance-metadata', 'node_id'),
                   'user_id': uid,
                   'tenant_id': tid,
                   'timestamp': datetime.datetime.now(tz=timezone).isoformat(),
                   'vendor': 'Menlo Security',
                   }

      result = 'continue'
      all_futures = {}

      # Store plugin names that have been requested to be skipped by another.
      # TODO: This mechanism should be expanded if inter-communication or
      # inter-dependency between plugins becomes common. Currently only used
      # to flag the sandbox be skipped by av_scan.
      # By default, the sandbox should always be skipped, unless an av_scan
      # requests it.
      skip_plugins = {'sandbox': True}

      plugin_results = []
      plugin_count = 0
      total_plugins = len(av_response['file_processing_list'])
      for action in av_response['file_processing_list']:
         start_time = monotonic()
         if skip_plugins.get(action['plugin'], False):
            self.log.info({'action': action['plugin'],
                           'file_id': self.file_id},
                          event='requested-plugin-skipped')
            continue

         try:
            action_plugin = ACTION_PLUGIN_MAPPING[action['plugin']]
         except KeyError:
            self.log.error({'action': action['plugin'],
                            'file_id': self.file_id},
                           event='required-plugin-missing',
                           opslog=True)
            raise

         self.log.debug({'filename': file_info['local_filename'],
                         'plugin_type': action_plugin,
                         'work_dir': file_info['work_dir'],
                         'suggested_filename': file_info['suggested_filename'],
                         'file_id': self.file_id},
                        event='run-file-processing-plugin', opslog=False)

         config_dict = {'config': action['config'],
                        'credentials': action['credentials'],
                        'work_dir': file_info['work_dir'],
                        'filename': file_info['suggested_filename'],
                        'meta_data': meta_data,
                        'log': self.log,
                        'svconf': config,
                        'hashing_executor': hashing_executor,
                        'file_id': self.file_id,
                        }
         config_dict['credentials'].update(
            {'encryption_info': file_info['encryption_info']})
         plugin_entry = {}
         plugin_entry['name'] = action['plugin']

         # Update the stage the file is at, to show progress through the
         # pipeline in the UX (current stage and total number of stages)
         plugin_count += 1
         self.application.progress_store.update_plugin_stage(self.file_id,
                                                             plugin_count,
                                                             total_plugins)

         self.log.increment('plugin-run-%s' % (action['plugin']))
         try:
            plugin_instance = action_plugin(config_dict)
         except Exception:
            result = result_code_to_outcome(
               action['plugin'], ResultCodes.PLUGIN_FAILED)
            self.log.increment('plugin-result-%s-failure' % (action['plugin']))
            continue

         if action['criticalpath'] and result not in [ALLOW, BLOCK]:
            # Action is on critical processing path, and no actions have
            # responded allow or block so far, so run the plugin and yield the
            # returned future to the coroutine.
            result, result_data = yield self._handle_plugin_completion(
               action['plugin'], file_info['suggested_filename'],
               plugin_instance.run())

            # Get the dict of any plugins which should now be skipped (or not)
            # based on the result of this plugin.
            skip_plugins.update(result_data.get('skip_plugins', {}))

            # Add result_data into plugin_results
            plugin_entry.update(result_data)

            # Add time taken to run to plugin_entry
            time_taken = monotonic() - start_time
            self.log.timer('file-process-time-%s' % action['plugin'], time_taken)

         elif action['always']:
            # Action not on critical path, or was but processing has resulted
            # in allow or block; in either case, the plugin is instructed to
            # always run, so create a job, and add the future to the ioloop to
            # log the outcome.
            future = plugin_instance.run()
            all_futures[action['plugin']] = future

         else:
            # File processing has resulted in an allow or block, and current
            # action is not required to always run, so continue.
            pass

         plugin_results.append(plugin_entry)

         # If this file is being viewed in safedocs, update the scanning status
         if self.docid:
            yield self._set_safedoc_download_policy(
               av_response['transfer_safe'], PENDING,
               av_response['av_scan_result'], av_response['virus_details'],
               stage=plugin_count, total_stages=total_plugins)

      if result not in [ALLOW, BLOCK]:
         # If we reach the end of the processing list and no plugin has
         # explicitly blocked, then allow.
         result = ALLOW

      raise tornado.gen.Return((result, plugin_results, all_futures))

   @tornado.gen.coroutine
   def _handle_plugin_completion(self, plugin_name, filename, future):
      """Common handling of the plugin result."""
      result_data = None
      try:
         _result, result_data = yield future
         result = result_code_to_outcome(plugin_name, _result)
         log_dict = result_data.copy()
         log_dict.pop('credentials', None)
         self.log.info({'filename': filename, 'plugin_name': plugin_name,
                        'result': result, 'result_data': log_dict},
                       event='plugin-result')
      except Exception as e:
         _result = ResultCodes.PLUGIN_FAILED
         result = result_code_to_outcome(plugin_name, _result)
         self.log.warning({'filename': filename, 'plugin_name': plugin_name,
                           'result': result,
                           'error': '%s: %s' % (type(e).__name__, e)},
                          event="plugin-failed", opslog=True)

      if _result == ResultCodes.PLUGIN_FAILED:
         self._report_safefile_failure(result_data)
      self.log.increment('plugin-result-%s-%s' % (
                         plugin_name, ResultCodes.to_string(_result)))

      raise tornado.gen.Return((result, result_data))

   def _report_safefile_failure(self, result_data):
      """Report a file export failed event."""

      # We don't know the state of the result data, so catch any issues
      try:
         data = {'reason': result_data['error'],
                 'target_url': result_data['meta_data']['src_uri']}
         self.report_event('file_export_failed', data=data)
      except Exception as ex:
         self.log.exception({'error': '%s: %s' % (type(ex).__name__, ex)},
                            event='unexpected-error.4')

   # pylint: disable=too-many-branches
   # pylint: disable=too-many-statements
   @tornado.gen.coroutine
   def resolve_file_encryption(self, work_dir, file_name):
      """ Handle password prompting for archives and documents

      This function is called only when the following two conditions are met
         1. The file is encrypted (password protected)
         2. Password prompt option is set in the plugin chain
      In common, it GETs api/v1/password API of Safedocs for asking password
      and getting password when it is inserted by the user.
      For archive, try to unzip the original file to check if the password is
      correct. For document, try to decrypt it using QPDF or other utils to
      verify the password, and then make a copy of the decrypted document
      for virus scan and document isolation.
      Finally this function reports the result of the decryption via POSTing
      to api/vi/password.
      """
      file_type = self._req_params['file_type']
      # Check password prompt option is enabled
      cid = str(uuid.uuid4())
      if not self.enc_detail.get('encrypted'):
         raise tornado.gen.Return(False)
      try:
         container_result = yield runc_sandbox.execute_async(
            {'cmd': 'create_container',
             'container_id': cid,
             'input_dir': work_dir,
             'work_dir': os.path.join(work_dir, 'decryption'),
             'uid': os.getuid(), 'gid': os.getgid()})
         if not container_result.get('result'):
            raise tornado.gen.Return(False)

         if self.enc_detail.get('archive_scan'):
            yield self.handle_safedocs_transfer(
               file_type, self._req_params.get('read_only', False))
         elif self.enc_detail.get('file_type') == FileType.PDF:
            yield self.handle_safedocs_transfer(
               file_type, self._req_params.get('read_only', False))
         if not self.docid:
            raise tornado.gen.Return(False)
         # Poll Safedocs to retrieve the password
         tmp_password = ''
         password_resolved = False
         retry_limit = PASSWORD_PROMPT_RETRY_LIMIT
         poll_limit = PASSWORD_PROMPT_TIMEOUT_SEC
         while poll_limit and retry_limit:
            yield tornado.gen.sleep(1)
            try:
               http_client = tornado.httpclient.AsyncHTTPClient()
               response = yield http_client.fetch(
                  self.get_docview_api('docview/api/v1/password/%s' %
                                       self.docid),
                  method='GET')
               tmp_password = json.loads(response.body).get('password')
               if not tmp_password:
                  self.log.info({'docid': self.docid,
                                 'container_id': cid,
                                 'file_name': file_name},
                                event='failed-getting-password-from-json')
                  continue
               if self.enc_detail.get('archive_scan'):
                  zip_file_list = self.enc_detail.get('zip_list',
                                                      {}).get('files', [])
                  if zip_file_list:
                     # Try to unzip one file in the list
                     unzip_result = yield runc_sandbox.execute_async(
                        {'cmd': 'unzip',
                         'file_path': '/safefile-input',
                         'file_name': file_name,
                         'target_file': zip_file_list[0]['Path'],
                         'password': tmp_password,
                         'container_id': cid})
                     password_resolved = unzip_result.get('result')
               elif self.enc_detail.get('file_type') == FileType.PDF:
                  decrypted_filename = 'decrypted_' + file_name
                  result = yield runc_sandbox.execute_async(
                     {'cmd': 'decrypt_pdf',
                      'file_path': '/safefile-input',
                      'file_name': file_name,
                      'decrypted_filename': decrypted_filename,
                      'password': tmp_password,
                      'container_id': cid})
                  self.log.info(result, event='decrypt_pdf')
                  if result.get('result'):
                     # Decrypted PDF is stored in workdir/decryption/cid
                     # copy it back to input location
                     shutil.copy(os.path.join(work_dir,
                                              'decryption',
                                              decrypted_filename),
                                 work_dir)
                     os.chmod(os.path.join(work_dir, decrypted_filename), 0664)
                     self.enc_detail['decrypted_filename'] = \
                        os.path.join(work_dir, decrypted_filename)
                     password_resolved = True
               if not password_resolved:
                  # Password is wrong. decrease the retry count, and reset
                  # the poll_limit
                  retry_limit -= 1
                  poll_limit = PASSWORD_PROMPT_TIMEOUT_SEC
                  self.log.debug({'docid': self.docid,
                                  'container_id': cid,
                                  'file_name': file_name},
                                 event='wrong-password')
                  continue
            except tornado.httpclient.HTTPError as e:
               # Safedocs is still waiting for the password to be put
               self.log.debug({'docid': self.docid,
                                 'container_id': cid,
                                 'file_name': file_name,
                                 'error': '%s: %s' % (type(e).__name__, e)},
                              event='password-not-ready')
            except Exception as e:
               # Unrecoverable. Give up getting password
               self.log.info({'docid': self.docid,
                              'container_id': cid,
                              'file_name': file_name,
                              'error': '%s: %s' % (type(e).__name__, e)},
                             event='failed-getting-password-exception')
               break
            else:
               # Got the correct password!
               self.enc_detail['password'] = tmp_password
               break
            finally:
               poll_limit -= 1
         # Loop is done. Report the result to Safedocs
         try:
            # Notify the password result
            http_client = tornado.httpclient.AsyncHTTPClient()
            yield http_client.fetch(
               self.get_docview_api('docview/api/v1/password/%s'
                                    % self.docid),
               method='POST',
               headers={'content-type': 'application/json'},
               body=json.dumps({
                  'result': password_resolved,
                  'encryption_info': self.enc_detail
               }))
         except Exception as e:
            self.log.info({'docid': self.docid,
                            'file_name': file_name,
                            'error': '%s: %s' % (type(e).__name__, e)},
                           event='could-not-resolve-password')
         else:
            raise tornado.gen.Return(password_resolved)

      finally:
         # Delete container
         result = yield runc_sandbox.execute_async({'cmd': 'delete_container',
                                                    'container_id': cid})
         if not result.get('result'):
            # Leave a log only when container was created, and failed to delete
            if container_result.get('result'):
               self.log.error({'file_name': file_name,
                               'container_id': cid,
                               'docid': self.docid},
                              event='failed-to-delete-container', opslog=True)
      raise tornado.gen.Return(False)

   # pylint: disable=too-many-branches
   @tornado.gen.coroutine
   def run_av_plugins(self, local_filename, suggested_filename, docid,
                      av_response, session_id, work_dir):

      self.log.gauge('file-size', self.total_size)

      file_type = self._req_params['file_type']
      # If this file is going to safedocs...
      # Send the initial download policy results to safedocs (this can be
      # modified later when we have the full results, in particular, whether
      # the original download is allowed or blocked)
      if self.docid:
         yield self._set_safedoc_download_policy(
            av_response['transfer_safe'], PENDING,
            av_response['av_scan_result'], av_response['virus_details'])

      # Define what should happen if malware found
      action_on_malware = av_response.get('action_on_malware', BLOCK)

      remaining_futures = {}
      risks = []
      analytics = {}


      # If we already have a block from pnr-e and the file hasn't gone to
      # safedocs, send that 'block' back now but continue with the processing
      # for logging / analysis purposes.
      if (av_response['transfer_original'] == BLOCK and not self.docid):
         yield self.set_transaction_result(av_response)

      if av_response.get('file_processing_list'):
         # Do all the file processing, and tidy up the stuff
         try:
            outcome, plugin_results, remaining_futures = \
               yield self._action_processing_list(
                  {'local_filename': local_filename,
                     'suggested_filename': suggested_filename,
                     'work_dir': work_dir,
                     'file_type': file_type,
                     'encryption_info': self.enc_detail},
                  av_response)
            # Record if we blocked because of an Unknown VT result where the
            # scan showed a Clean file.
            if (av_response['action_on_unknown'] == 'block' and
                outcome == 'ALLOW'):
               self.log.info({'avcheck': av_response['action_on_unknown'],
                              'outcome': outcome,
                              'action_on_malware': action_on_malware},
                              event='unknown-blocked-on-clean-scan')

            # Build up what we need to record about the consolidated results
            for result in plugin_results:

               # Malware/Infected result
               if result.get('infected'):
                  av_response['av_scan_result'] = 'Infected'
                  # Add 'Infected' as the risk unless a specific risk has
                  # been given in the results.
                  if not result.get('risk'):
                     risks.append('Infected')
               if result.get('analytics'):
                  analytics.update(result.get('analytics'))

               # Plugins could have other results in the future
               # (e.g. Sanitized/Cleaned/DLP Block)

               # Risk: Infected, vulnerable, cats, plugin, mdbl, rep, Unknown
               if result.get('risk'):
                  risks.append(result['risk'])

         except Exception as e:
            # File processing encountered an exception, fall back to the
            # original PE decision.
            # TODO: This should use the fallback policy specified for the
            # plugin by the user when we have this in policy
            self.log.warning({'filename': suggested_filename,
                              'doc_id': docid,
                              'error': '%s: %s' % (type(e).__name__, e)},
                              event='file-processing-failed', opslog=True)
            outcome = av_response['transfer_original']

         if outcome == BLOCK and av_response['transfer_original'] != BLOCK:
            av_response['transfer_original'] = action_on_malware

      # If after we finish processing the plugins the result is still
      # 'unknown' we should take the actionOnUnknown provided by pnr-e
      if (av_response['transfer_original'] == 'unknown' or
          av_response['av_scan_result'] == 'Unknown'):
         self.log.info({'result':'unknown',
                        'transfer_original': av_response['transfer_original'],
                        'av_scan_result': av_response['av_scan_result'],
                        'actionOnUnknown': av_response.get('action_on_unknown')},
                        event='unknown-scan-result')
         # Set the result to actionOnUnknown and add 'Unknown' to risks
         # The call to avlog will add the rest of metadata
         if av_response['transfer_original'] == 'unknown':
            av_response['transfer_original'] = av_response.get('action_on_unknown', BLOCK)
         risks.append('Unknown')

      self.log.debug({'filename': local_filename, 'doc_id': docid,
                      'transfer_original': av_response['transfer_original'],
                      'transfer_safe': av_response['transfer_safe']},
                      event='set-result', opslog=False)

      assert(av_response['transfer_original']in [ALLOW, BLOCK])

      # Respond to thin client or post results to safedocs policy API
      yield self.set_transaction_result(av_response)

      # Yield the remaining futures one-by-one so all outcomes are recorded
      # and directory can be cleaned up when all are completed.
      for plugin_name, future in remaining_futures.items():
         result, result_data = yield self._handle_plugin_completion(
            plugin_name, suggested_filename, future)
         # These plugins can add analytics data but cannot affect the policy
         # result (e.g. forensic archive)
         if result_data.get('analytics'):
            analytics.update(result_data.get('analytics'))

      # Add remaining data into AnalyticsData to go to Druid/Kafka
      analytics['file_size'] = self.total_size
      analytics['filename'] = suggested_filename
      analytics['file_id'] = self.file_id

      # Call back into pnr-e with the final download decision and additional
      # results from the plugins so that the results can be logged to kafka.
      yield self._log_transfer_result(
         docid, av_response, risks, analytics, session_id)

   # pylint: enable=too-many-branches
   def handle_request_exception_handler(self, future):
      """Top level exception handler for the entire request.

      This along with on_auth_success works like a 'try/except' around
      the entire handle_request function and all of its processing.
      """
      try:
         future.result()
      except Exception as ex:
         # Catch unhandled exceptions and finish with error
         self.log.exception({'error': '%s: %s' % (type(ex).__name__, ex)},
                            event='unexpected-error.1')
         if hasattr(self, 'file_id'):
            self.application.progress_store.set_file_error(self.file_id)

   @tornado.gen.coroutine
   def _log_transfer_result(self, docid, av_response, risks, analytics, cache_key):
      """Send a request to pnr-e to pass back the findings from the
         antivirus scans and file extraction."""

      self.log.info({'transfer_original': av_response['transfer_original'],
                     'transfer_safe': av_response['transfer_safe'],
                     'virus_details': av_response['virus_details'],
                     'av_vendors': av_response['av_vendors'],
                     'risks': risks,
                     'analytics': analytics,
                     'cache_key': cache_key,
                     'doc_id': docid,
                     'file_id': self.file_id},
                    event='final-transfer-policy', opslog=False)

      if not config.getboolean('policy-enforcement-server', 'enabled'):
         # No pnr available, no point going any further
         return

      # pnr-e call to avlog with additional event metadata to finalize
      # the druid logging call and actually log the message to Kafka
      pnr = PNRHelper()
      event = pnr.populate_event_data(None, self.get_current_user(),
                                      self.request,
                                      nav_session_id=cache_key)

      event['download_original'] = av_response['transfer_original']
      event['cache_key'] = cache_key
      if 'user_agent' in self._req_params:
         event['user_agent'] = self._req_params['user_agent']

      # If a virus has been found, we need to log the details with pnr-e avlog
      if av_response['av_scan_result'] == 'Infected':
         event['pe_reason'] = 'av_Infected'
         # NB: virus_details, risks, risks_v2 and av_scan_result are lists
         # Details of virus, e.g. BitDefender|EICAR-Test-File (not a virus)
         event['virus_details'] = av_response['virus_details']
         # Risks is a list of risks (eg. 'Infected') and matches risks_v2.
         # These need to be one of: Infected, vulnerable, cats, plugin,
         # mdbl, rep, or Unknown.
         event['risks'] = risks
         event['risks_v2'] = risks
         event['av_scan_result'] = 'Infected'
         event['av_vendors'] = av_response['av_vendors']
         # Threat Type: Change this to something else? E.G. 'Malware'
         event['top_level_risks'] = ['Risky File']
         # Turn the druid log entry status to 'Red' indicating a dangerous file
         event['code'] = 'R'
         self.log.increment('file-infected')
         for virus_detail in av_response['virus_details']:
            virus = virus_detail
            try:
               vn = virus_detail.split('|')
               vn_sanitized = vn[1].split(' ')
               virus = vn_sanitized[0]
            except Exception:
               pass

            self.log.debug({'virus': virus}, event='virus')
            self.log.increment('file-infection-%s' % virus)
      else:
         self.log.increment('file-clean')

      # If we have an unknown risk, add it to the event and set the code to Y
      if 'Unknown' in risks:
         event['risks'] = risks
         event['risks_v2'] = risks
         event['top_level_risks'] = ['Risky File']
         # Turn the druid log entry status to 'Yellow' if currently not 'Red'
         if event.get('code') != 'R':
            event['code'] = 'Y'

      self.log.increment('file-originals-blocked' if av_response['transfer_original'] == BLOCK
                         else 'file-originals-allowed')

      # Add custom analyticsData entries for druid created by the file
      # processing plugins themselves (e.g. full scan virus results, etc.)
      event['analyticsData'] = analytics

      try:
         response = yield tornado.gen.Task(
            pnr.post_request, '/api/v1/pe/avlog', event)

         # This will happen if we blocked due to the file-type in get_pnr_policy
         if not response:
            self.log.info(event,
                           event='avlog-transfer-result-error', opslog=False)

      except Exception as ex:
         # Catch this as an 'isolate' response already sent to thin client
         self.log.exception({'error': '%s: %s' % (type(ex).__name__, ex),
                             'method': '_log_transfer_result'},
                            event='unexpected-error.2')


class SurrogateProcessingHandler(AddForensicChecks, RequestHandler):
   """Returns action to take for a given upload."""
   DIRECTION = ProgressStore.UPLOAD
   redis = None
   docid = None

   @classmethod
   def redis_get_value(cls, field):
      REDIS_KEY_NAME = 'GSM'
      if not cls.redis:
         log.info({}, event='redis-init')
         cls.redis = safly.redis_client.get_redis()

      return cls.redis.hgetx(REDIS_KEY_NAME, field)

   def _lookup_by_upload_filename(self, bid, upload_path):
      """Returns filename of the uploaded file.

      Given the file's @upload_path and the @bid of the renderer that is due
      to upload it, the fileserver's local path is returned.
      It throws if the file does not exists
      """
      surrogate_json = self.redis_get_value(bid)

      if not surrogate_json or surrogate_json.startswith('Pending_'):
         raise Exception('Redis Lookup failure')

      surrogate_info = tornado.escape.json_decode(surrogate_json or '{}')
      secret_rid = surrogate_info.get('secret_rid')
      if not secret_rid:
         raise Exception('Invalid bid')

      if not os.path.isabs(upload_path):
         raise Exception('Relative pathnames are not permitted')

      local_filename = os.path.join(
         config.get('surrogate', 'chroot_home'), secret_rid,
         os.path.relpath(upload_path, '/')).encode('utf-8')

      # Make sure there are no symlinks, '/../', etc. in the path
      if local_filename != os.path.normpath(local_filename):
         raise Exception('Invalid path component')

      if not os.path.isfile(local_filename):
         log.info({'file': local_filename}, event='upload-file-not-present')
         raise Exception('File not present')

      return local_filename

   def get_current_user(self, max_age_days=1):
      # unlike the download case, we are not authenticated, so we need to get
      # the uid, and tid from the client (who we trust).
      return self._req_params

   def prepare_file(self, original_file, working_file):
      """Copy the original_file to working_file.

      On file uploads the file does not need to be copied into the file-server
      download directory, as it will not need to be served for download.
      This prepare_file therefore cannot use the default hardlink, and
      actually does the copy from the surrogate-fs itself.
      """
      self.log.debug({'original_file': original_file,
                      'working_file': working_file},
                     event='prepare-file-upload')
      shutil.copy(original_file, working_file)

   @tornado.gen.coroutine
   def handle_upload_request(self, *args, **kwargs):
      """Start to handle request for get_action.

      This is the entry point of the request in file-server from the Surrogate,
      sent after the TC has pushed an upload file to it.
      """
      self.docid = None
      self.enc_detail = {}
      start_time = monotonic()
      self.file_id = self._req_params['file_id']
      self.src_uri = self._req_params['src_uri']

      # Copy the file out of the surrogate for the AV processing
      try:
         surrogate_file = self._lookup_by_upload_filename(
            self._req_params['safe_bid'], self._req_params['filepath'])
      except Exception as ex:
         self.log.error({'file_id': self.file_id,
                         'src_uri': self.src_uri,
                         'upload_id': self._req_params['upload_id'],
                         'error': '%s: %s' % (type(ex).__name__, ex)},
                        event='handle-upload-request-error')
         # File was not uploaded fully by the surrogate browser, return error
         self.application.progress_store.insert_file_tc(
            self.file_id, 'error', self._req_params['uid'],
            self._req_params['tid'], None, self.DIRECTION)
         self.application.progress_store.set_file_error(self.file_id)
         self.finish()
         return

      # Get the filename of the file being uploaded (unlike download this isn't
      # from the src uri).
      suggested_filename = os.path.basename(surrogate_file)

      # Split the file extension and pass to get_file_type_from_file
      file_type, mime_type = get_file_type_from_file(
         surrogate_file, os.path.splitext(surrogate_file)[1])
      self._req_params['file_type'] = file_type
      self._req_params['mime_type'] = mime_type

      self.log.increment('file-upload-type-%s' % file_type)
      self.log.increment('file-upload')
      self.log.info({'surrogate_file': surrogate_file,
                     'upload_filepath': self._req_params['filepath'],
                     'upload_id': self._req_params['upload_id'],
                     'src_uri': self.src_uri,
                     'file_id': self.file_id,
                     'file_type': file_type},
                    event='handle-upload-request', opslog=False)

      # Add the file to the progress_store.
      self.application.progress_store.insert_file_tc(
         self.file_id, suggested_filename, self._req_params['uid'],
         self._req_params['tid'], None, self.DIRECTION)

      self.total_size = os.path.getsize(surrogate_file)
      self.application.progress_store.update_current_file_size(
         self.file_id, self.total_size)

      # Set file processing before finish() or 'pending' state will change
      # to 'block' in the status handler.
      self.application.progress_store.set_file_processing(self.file_id)

      # Respond to the request now an entry is made. Chromium will now
      # poll for status to monitor the progress.
      self.finish()

      # Get the file policy from pnr-enforcement
      # Equivalent of get_pnr_policy has already been done by Chromium
      # If the upload was blocked already, it will have been logged by the call
      # to pnr-e in Chromium and never arrived here, so we know the pnr policy
      # for the upload is ALLOW and at this point hasn't been logged to druid.

      # user_policy in pnr-e uses this key for file upload caching rather than
      # nav_session_id. TODO: Find a better method to track isolated uploads.
      session_id = 'file-upload-%s-%s' % (self._req_params['tid'],
                                          self._req_params['uid'])

      # Run avcheck for upload path
      av_response = yield self.do_avcheck(
         ALLOW, self.src_uri, surrogate_file, session_id)

      with working_directory() as work_dir:
         # Create a hard link of the original file to the
         # working directory
         yield self.application.executor.submit(
            self.prepare_file, surrogate_file,
            os.path.join(work_dir, suggested_filename))
         # Run AV plugins for upload
         yield self.run_av_plugins(surrogate_file, suggested_filename, None,
                                   av_response, session_id, work_dir)

      time_taken = monotonic() - start_time
      self.log.timer('file-process-time', time_taken)

   @tornado.web.asynchronous
   def post(self, *args, **kwargs):
      """Start to handle request for upload get_action.

      This is the entry point of the request in file-server from the Surrogate,
      sent after the TC has pushed an upload file to it.
      """
      self._req_params = tornado.escape.json_decode(self.request.body or '{}')
      if not self.enforce_request_completness(
            query_keys={},
            body_keys={
               'filepath', 'uid', 'tid', 'safe_bid', 'upload_id', 'file_id'}):
         raise self.badrequest('Invalid API request')

      tornado.ioloop.IOLoop.instance().add_future(
         self.handle_upload_request(), self.handle_request_exception_handler)


class DownloadProcessingMixin(AddForensicChecks):
   """Mixin providing various support methods for download handlers."""
   DIRECTION = ProgressStore.DOWNLOAD

   def get_external_safedocs_prefix(self):
      raise NotImplementedError

   def get_docview_api(self, path):
      """Get REST API url used to communicate with safedocs APIs"""
      url = 'http://10.3.0.1:%s' % (config.getint('docview', 'port'))
      return urlparse.urljoin(url, path)

   def _is_isolated_docview_download(self):
      doc_path = self.get_docview_api('docview')
      return (self._req_params.get('src_uri', '').startswith(
              doc_path + '/download'))

   def _should_isolate_safedocs(self):
      return True
      tid = self.get_current_user().get('tid', -1)
      internal_docview_tenants = config.get('file-server',
                                            'isolated_docview_tenants')
      return (str(tid) in internal_docview_tenants.split(','))

   @tornado.gen.coroutine
   def _isolate_file(self, file_type, read_only):
      """Invoke safedocs to isolate the given file.

      Returns docid or None if the upload fails.
      """

      local_filename, file_name = \
         self.application.progress_store.get_file_path_and_name(self.file_id)

      self.log.increment('file-transfers-requested')

      # Allow sv-docs and runC container to read the file
      # r/w for sv-file user and group (so sv-docs can also r/w)
      # others need 'r' so that runC 'root' user can access the file
      os.chmod(local_filename, 0664)

      safedocs_url = config.get('docview', 'post_url')
      # Prepend the haproxy host and internal port if not already absolute
      safedocs_url = self.get_docview_api(safedocs_url)

      # pylint: disable=arguments-differ
      user_info = self.get_current_user()
      headers = {'content-type': 'application/json'}
      data = {'file_name': file_name,
              'file_path': local_filename,
              'file_type': file_type,
              'original_uri': self.src_uri,
              'user_id': user_info['uid'],
              'tenant_id': user_info['tid'],
              'safe_bid': user_info['safe_bid'],
              'file_id': self.file_id,
              'viewer_isolation': self._should_isolate_safedocs(),
              'read_only': read_only,
              'start_conversion': True}
      if (self.enc_detail.get('encrypted') or
         file_type in ARCHIVE_SCAN_CANDIDATE):
         data.update({'encryption_info': self.enc_detail,
                      'start_conversion': False})

      docid = None
      try:
         http_client = tornado.httpclient.AsyncHTTPClient()
         response = yield http_client.fetch(safedocs_url,
                                            method='POST',
                                            headers=headers,
                                            body=json.dumps(data))
         docid = json.loads(response.body)['id']
      except Exception as ex:
         # Unable to contact safedocs (timed out or failed response) or
         # safedocs has rejected this document isolation request.
         self.log.error({'error': ex}, event='upload-response-error',
                        opslog=True)
         return

      self.log.increment('file-transfers-completed')
      self.log.info({'local_filename': local_filename,
                     'doc_id': docid},
                    event='file-transfer-safedocs-success', opslog=False)

      raise tornado.gen.Return(docid)

   @tornado.gen.coroutine
   def _set_safedoc_download_policy(self, transfer_safe, transfer_original,
                                    av_scan_result=None, virus_details=None,
                                    stage=None, total_stages=None):
      """Send a POST request to the safedocs server to set the original
         and safe download policy."""
      if transfer_original != PENDING:
         self.log.info({'original_download': transfer_original,
                        'safe_download': transfer_safe,
                        'av_scan_result': av_scan_result,
                        'virus_details': virus_details,
                        'doc_id': self.docid},
                       event='safedoc-download-policy', opslog=False)

      policy_url = config.get('docview', 'policy_url')
      policy_url = policy_url + self.docid
      # Prepend the haproxy host and internal port if not already absolute
      policy_url = self.get_docview_api(policy_url)
      headers = {'content-type': 'application/json'}
      data = {'download_original': transfer_original,
              'download_safe': transfer_safe}
      if av_scan_result:
         data['av_scan_result'] = av_scan_result
      if virus_details:
         data['virus_details'] = virus_details
      if stage and total_stages:
         data['stage'] = stage
         data['total_stages'] = total_stages

      try:
         http_client = tornado.httpclient.AsyncHTTPClient()
         req = tornado.httpclient.HTTPRequest(policy_url, method='POST',
                                              headers=headers,
                                              body=json.dumps(data))

         response = yield tornado.gen.Task(http_client.fetch, req)

         if response.error:
            self.log.error({'error': response.error},
                           event='set-download-policy-error', opslog=True)
      except Exception as ex:
         # Catch this as an 'isolate' response already sent to thin client
         self.log.exception({'error': '%s: %s' % (type(ex).__name__, ex),
                             'method': '_set_safedoc_download_policy'},
                            event='unexpected-error.3')
   @tornado.gen.coroutine
   def check_file_encryption(self, work_dir, file_name):
      file_type = self._req_params['file_type']
      enc_detail = {'file_type': file_type,
                    'archive_scan': False,
                    'encrypted': False,
                    'password': '',
                    'zip_list': {}}
      if (self.DIRECTION == 'upload' or (
          file_type not in ARCHIVE_SCAN_CANDIDATE and
          file_type not in PASSWORD_PROMPT_CANDIDATE)):
         raise tornado.gen.Return(enc_detail)
      # Create container and check if the file is encrypted
      cid = str(uuid.uuid4())
      try:
         container_result = yield runc_sandbox.execute_async(
            {'cmd': 'create_container',
             'container_id': cid,
             'input_dir': work_dir,
             'work_dir': os.path.join(work_dir, 'decryption'),
             'uid': os.getuid(), 'gid': os.getgid()})
         if not container_result.get('result'):
            raise tornado.gen.Return(enc_detail)
         if file_type == FileType.PDF:
            result = yield runc_sandbox.execute_async(
               {'cmd': 'check_pdf_encryption',
                'file_path': '/safefile-input',
                'file_name': file_name,
                'container_id': cid})
            if result.get('result') and result.get('encrypted'):
               enc_detail['encrypted'] = True
         elif file_type in ARCHIVE_SCAN_CANDIDATE:
            if config.get('file-server', 'archive_scan'):
               zip_list = yield runc_sandbox.execute_async(
                  {'cmd': 'get_zip_list',
                   'file_path': '/safefile-input',
                   'file_name': file_name,
                   'file_type': file_type,
                   'container_id': cid})
               if zip_list.get('result') and zip_list.get('files'):
                  enc_detail['zip_list'] = zip_list
                  enc_detail['archive_scan'] = True
                  if zip_list.get('encrypted'):
                     enc_detail['encrypted'] = True
      finally:
         result = yield runc_sandbox.execute_async({'cmd': 'delete_container',
                                                    'container_id': cid})
         if not result.get('result'):
            # Leave a log only when container was created, and failed to delete
            if container_result.get('result'):
               self.log.error({'file_name': file_name,
                               'container_id': cid,
                               'docid': self.docid},
                              event='failed-to-delete-container', opslog=True)
      raise tornado.gen.Return(enc_detail)

   @tornado.gen.coroutine
   def process_file(self, policy, session_id, local_filename,
                    suggested_filename):
      file_type = self._req_params['file_type']
      read_only = self._req_params.get('read_only', False)

      # Use the context manager to ensure the cleanup of the working directory
      # at the end of the request.
      with working_directory() as work_dir:
         # Create a hard link of the original file to the
         # working directory
         yield self.application.executor.submit(
            self.prepare_file, local_filename,
            os.path.join(work_dir, suggested_filename))
         self.enc_detail = yield self.check_file_encryption(work_dir,
                                                            suggested_filename)
         self.log.debug(self.enc_detail, event='file-encryption-info')
         self.application.progress_store.set_encryption_detail(self.file_id,
                                                               self.enc_detail)
         if not self.enc_detail.get('encrypted'):
            # If the file is not encrypted, docview enabled and policy is to
            # SAFEDOC, send to safedocs.
            if config.getboolean('docview', 'enable') and (policy == SAFEDOC):
               yield self.handle_safedocs_transfer(file_type, read_only)
         self.application.progress_store.set_file_type(
            self.file_id, file_type, self._req_params.get('mime_type'))
         if not self.docid:
            # docid is not set, file was not uploaded to safedocs
            self.application.progress_store.set_file_processing(
               self.file_id)

         # Regardless of whether file was sent to safedocs, perform avcheck
         av_response = yield self.do_avcheck(
            policy, self.src_uri, local_filename, session_id,
            self._req_params.get('analytics', None))
         # If we are not using policy but anti-virus scanning is enabled by
         # config then we need to add a block to perform the anti-virus scan
         if (not config.getboolean('policy-enforcement-server', 'enabled') and
             config.getboolean('safefile', 'avengine')):
            av_response['file_processing_list'] = \
               [DEFAULT_FILE_PROCESSING_BLOCK]

         # Prompt password if necessary
         if self.enc_detail.get('encrypted'):
            plugin_list = av_response.get('file_processing_list', [])
            # If plugin is empty, or if any password_prompt flag is set to
            # True, run password prompting.
            if not plugin_list or \
                  any(plugin.get('config', {}).get('password_prompt') for
                      plugin in plugin_list):
               yield self.resolve_file_encryption(work_dir,
                                                  suggested_filename)
            else:
               # The file is encrypted but we are not allowed to prompt
               # password. We will fail archive scanning.
               self.log.info('Password prompting is disabled.',
                             event='skip-password-prompt')
               self.enc_detail['archive_scan'] = False
               self.enc_detail['encrypted'] = False

         yield self.run_av_plugins(
            local_filename, suggested_filename, self.docid, av_response,
            session_id, work_dir)

   @tornado.gen.coroutine
   def handle_safedocs_transfer(self, file_type, read_only):
      """Handle sending the file to safedocs.

      Setting of self.docid is used to determine if file is in safedocs and
      how the final policy should be set.
      """
      # Upload the file and redirect to safedocs
      self.docid = yield self._isolate_file(file_type, read_only)

      if self.docid:
         if self._should_isolate_safedocs():
            # Use surrogate route
            safedocs_url = '%s/doc/%s'
         else:
            # Use public route
            safedocs_url = '%s/docview/viewer/%s'

         safedocs_url = safedocs_url % (self.get_external_safedocs_prefix(),
                                        self.docid)
         # Update the progress_store
         self.application.progress_store.set_file_safedoc_processing(
            self.file_id, safedocs_url)


@tornado.web.stream_request_body
class ICAPTransferHandler(DownloadProcessingMixin, RequestHandler):
   """Handler to receive downloaded files from the ICAP server for processing.

   This handler receives the data stream from the ICAP server, and writes the
   file to a working directory ready for hashing and processing.
   Once the file has been written to disk, processing should proceed as with
   the isolated page download.
   """
   executor = concurrent.futures.ThreadPoolExecutor(
      max_workers=config.getint('file-server', 'max_icap_transfer_threads'))

   def __init__(self, *args, **kwargs):
      super(ICAPTransferHandler, self).__init__(*args, **kwargs)
      self._req_params = {}
      self.log_data = {}
      self.chunks = []
      self.chunks_size = 0
      self.file_handler = None
      self.compressed_file_handler = None
      self.total_size = 0
      self.decompressor = None

   def prepare(self, *args, **kwargs):
      """Prepare to receive the file transfer.

      Create the working directory, create the file handler and transition
      the file_id's state to 'pending'. If there is insufficient space
      remaining to receive the file, set the file_id state to error.
      """
      super(ICAPTransferHandler, self).prepare(*args, **kwargs)

      # Check the api-secret is valid.
      if (self.request.headers['x-api-secret'] !=
          config.get('file-server', 'icap_fs_secret')):
         raise self.forbidden('Unauthorized access.')

      # Tornado default is to only allow a max file stream (max_body_size) of
      # 100MB. Increase for this request only to handle our internal limit.
      # The max_body_size is set here to actually be 10% higher than the
      # limit to allow this handler to intercept and error in the event the
      # limit is reached. If the actual limit was to be used it would close the
      # connection as expected, but at the expense of this handler not knowing
      # what error caused on_connection_close to be called. As such, the
      # max_body_size is set to be above the limit so the handler itself can
      # intercept the limit being exceeded, and the correct error can be
      # reported (block_max_size_exceeded).
      self.request.connection.set_max_body_size(config.getint(
         'file-server', 'max_file_download_size') * 1.1)

      # Decode meta-data about the file to be used by the request
      self._req_params = json.loads(
         b64decode(self.request.headers['x-api-property']))

      self.file_id = self._req_params['file_id']

      self.log_data = {'user_id': self._req_params['user_id'],
                       'tenant_id': self._req_params['tenant_id'],
                       'file_id': self.file_id}

      # Ensure file_id was generated by file-server by checking for its
      # existence in the progress_store.
      if not self.application.progress_store.check_exists_and_inbound(
            self.file_id):
         self.log.warning(
            self.log_data, event='invalid-file-id')
         raise self.forbidden('Invalid file_id specified.')

      if not self.application.space_available():
         # Not enough space remaining, set file_id state to error.
         self.log.warning(
            self.log_data, event='transfer-insufficient-disk-space')
         self.application.progress_store.set_file_error(self.file_id)
         raise tornado.web.HTTPError(status_code=503)

      self.log.info(self.log_data, event='icap-transfer-accepted')

      # Grab the original headers from the progress store
      original_headers = self.application.progress_store.get_original_headers(
         self.file_id)

      # Create any required decompressors based on the original headers
      if 'gzip' in original_headers.get('content-encoding', ''):
         self.decompressor = zlib.decompressobj(zlib.MAX_WBITS | 16)
      elif 'deflate' in original_headers.get('content-encoding', ''):
         self.decompressor = zlib.decompressobj(-zlib.MAX_WBITS)

      # Create a fixed length basename for the file, that is based on, but
      # is not, the original filename.
      file_name = hashlib.sha256(
         self._req_params['file_name'] or 'unknown').hexdigest()

      # If there is a decompressor, a copy of the original compressed file
      # will be needed in the event of a native download.
      if self.decompressor:
         compressed_file_path = os.path.join(
            self.application.progress_store.get_file_storage_dir(self.file_id),
            'compressed-%s' % file_name)
         self.compressed_file_handler = open(
            compressed_file_path, 'wb', config.getint('file-server',
                                                      'icap_buffer_size'))
         self.application.progress_store.update_compressed_file_path(
            self.file_id, compressed_file_path)

      # Create the file and file_handler
      file_path = os.path.join(
         self.application.progress_store.get_file_storage_dir(self.file_id),
         file_name)
      self.file_handler = open(
         file_path, 'wb', config.getint('file-server', 'icap_buffer_size'))
      self.application.progress_store.update_file_path(self.file_id, file_path)

      # Update the progress_store
      self.application.progress_store.set_file_pending(self.file_id)

      # Ready to receive the file. 'data_received' will now be called
      # repeatedly for each chunk transferred.

   def _should_isolate_safedocs(self):
      """Do not isolate Safedocs until surrogate can be preallocated
      for the ICAP download session"""
      # TODO: Remove or modify this function when the surrogate preallocation
      # is implemented.
      return True

   def get_external_safedocs_prefix(self):
      return 'https://%s' % self.domain_scheme.get_login_host()

   @tornado.concurrent.run_on_executor
   def _write_file_chunks(self):
      """Write chunks to disk using executor to unblock ioloop.

      This function will also perform any decompression, if required.
      """
      for chunk in self.chunks:

         # Perform any decompression
         if self.decompressor:
            self.compressed_file_handler.write(chunk)
            chunk = self.decompressor.decompress(chunk)

         self.file_handler.write(chunk)

      self.chunks = []
      self.chunks_size = 0

   @tornado.gen.coroutine
   def data_received(self, chunk):
      """Receive the streamed content and write to disk.

      This method is a coroutine calling _write_file_chunks so that the
      progress_store is updated on the ioloop, and not on a separate thread.
      """
      if chunk:
         self.chunks.append(chunk)
         l = len(chunk)
         self.chunks_size += l
         self.total_size += l

         self.application.progress_store.update_current_file_size(
            self.file_id, self.total_size)

         if self.total_size > config.getint(
               'file-server', 'max_file_download_size'):
            raise Exception('Exceeded max file size')

         # The chunks are stored in memory until they exceed this value to
         # prevent excessive switching into the threadpool.
         if self.chunks_size > config.getint('file-server', 'icap_buffer_size'):
            yield self._write_file_chunks()

   @tornado.concurrent.run_on_executor
   def _close_file(self):
      """Close files using executor to unblock ioloop as it will flush."""
      if self.file_handler:
         self.file_handler.close()
      if self.compressed_file_handler:
         self.compressed_file_handler.close()

   @tornado.gen.coroutine
   def on_connection_close(self):
      """Handle the connection closing early during file transfer.

      This will be called if data_received raises an exception above.
      """
      self.log.warning(self.log_data, event='icap-transfer-connection-closed')

      # Close the file handlers
      yield self._close_file()

      # Update the progress_store.
      if self.total_size > config.getint(
            'file-server', 'max_file_download_size'):
         self.application.progress_store.set_file_block_max_size_exceeded(
            self.file_id)
      else:
         self.application.progress_store.set_file_error(self.file_id)

      super(ICAPTransferHandler, self).on_connection_close()

   # pylint: disable=arguments-differ
   def get_current_user(self):
      """Emulate returning the user data.

      Since this request is coming from ICAP, the safeview cookie is not
      available, so emulate the fields that are required.

      TODO: PNRHelper requires the safe_bid?
      """
      return {'uid': self._req_params.get('user_id'),
              'tid': self._req_params.get('tenant_id'),
              'safe_bid': ''}

   @tornado.web.asynchronous
   def post(self):
      """Start to handle request once file has transfer has been successful.

      Once the file transfer has completed, this is the entry point to handle
      the request in file-server from the ICAP server. This is called after
      icap_server has sent the contents of the file.

      Starts the handle request coroutine and adds its future to the ioloop.
      """
      tornado.ioloop.IOLoop.instance().add_future(
         self.handle_transfer_request(), self.handle_request_exception_handler)

   @tornado.gen.coroutine
   def handle_transfer_request(self):
      """Handle processing the file for ICAP requests.

      Called when file transfer has been successful.
      """
      # Write any pending chunks
      yield self._write_file_chunks()
      # Close and flush the file so the entire contents can be read.
      yield self._close_file()

      # Close connection with ICAP server now file has been received.
      self.finish()

      # When docid is set, the document has been transfered to safedocs
      self.docid = None
      self.enc_detail = {}
      start_time = monotonic()

      local_filename, suggested_filename = \
         self.application.progress_store.get_file_path_and_name(self.file_id)

      self.log_data['file_size'] = self.total_size
      self.log.info(self.log_data,
                    event='icap-file-entered-fileserver', opslog=False)

      self.log.increment('file-download-type-%s' % self._req_params['file_type'])
      self.log.increment('file-download')
      self.log.increment('file-download-icap')

      # Retrieve the src_uri and analytics from the progress store
      # Stored in _req_params due to downstream reliance at this time
      self._req_params['src_uri'] = (
         self.application.progress_store.get_src_uri(self.file_id))
      self._req_params['analytics'] = (
         self.application.progress_store.get_analytics(self.file_id))

      self.src_uri = self._req_params.get('src_uri', '')

      # Equivalent of get_pnr_policy has already been done by the ICAP_server
      policy = SAFEDOC if self._req_params['safedocs'] else SAFEVIEW
      session_id = self._req_params['nav_session_id']
      yield self.process_file(policy, session_id,
                              local_filename, suggested_filename)
      time_taken = monotonic() - start_time
      self.log.timer('file-process-time', time_taken)

class TCProcessingHandler(DownloadProcessingMixin,
                          PermissiveServerCallHandler):
   """Initiates file processing for a given download."""

   def _verify_icap_response(self, response, metadata):
      try:
         user_info = self.get_current_user()
         uid = user_info['uid']
         tid = user_info['tid']
      except Exception as ex:
         self.log.warning({'error': ex},
                          event='icap-proxy-category-user-info-not-found')
         uid = 'Unknown'
         tid = -1
      icap_uid = response.get('user_id')
      icap_tid = response.get('tenant_id')
      tid_ok = icap_tid and str(icap_tid) == str(tid)
      # FIXME: Currently, pnr-icap-auth doesn't get the cookie information
      # for CORS requests (JIRA-PNR-1635).
      uid_ok = (metadata.get('cors_request') and icap_uid == 'Unknown'
                or icap_uid and uid == icap_uid)
      icap_xhr_url = response.get('xhr_url')
      proxy_category_result = response.get('result')
      return (uid_ok and tid_ok and proxy_category_result and icap_xhr_url
              and icap_xhr_url.startswith(metadata.get('xhr_url', '')))

   def get_external_safedocs_prefix(self):
      # do not need to use external prefix for TC
      return ''

   @tornado.gen.coroutine
   def handle_download_request(self):
      """Handle the request from TC."""
      # When docid is set, the document has been transfered to safedocs
      self.docid = None
      self.enc_detail = {}
      start_time = monotonic()
      user_info = self.get_current_user()
      # Use the download.key passed from the surrogate to id the file in
      # progress_store.
      self.file_id = self._req_params['file_id']
      self.src_uri = self._req_params['src_uri']

      # TODO (JIRA SV-3090): Take appropriate action based on metadata
      # TODO: Unpack the metadata into the progress_store.
      try:
         surrogate_file, suggested_filename, metadata = lookup_by_download_id(
            self._req_params['rid'], self._req_params['download_id'])
      except Exception as ex:
         self.log.error({'file_id': self.file_id,
                         'src_uri': self.src_uri,
                         'download_id': self._req_params['download_id'],
                         'error': '%s: %s' % (type(ex).__name__, ex)},
                        event='handle-download-request-error')
         # File was not downloaded fully by the surrogate browser, return error
         self.application.progress_store.insert_file_tc(
            self.file_id, 'error', user_info['uid'], user_info['tid'], None,
            self.DIRECTION)
         self.application.progress_store.set_file_error(self.file_id)
         self.finish()
         return

      self.log.info({'surrogate_file': surrogate_file,
                     'suggested_filename': suggested_filename,
                     'file_id': self.file_id,
                     'src_uri': self.src_uri},
                    event='handle-download-request', opslog=False)

      storage_dir = create_directory('downloads-' + str(self.file_id))

      # Add the file to the progress_store.
      self.application.progress_store.insert_file_tc(
         self.file_id, suggested_filename, user_info['uid'], user_info['tid'],
         storage_dir, self.DIRECTION)

      # Respond to the request as soon as we've put a record for the file into
      # the progress store, the TC will then start polling via /tc_status
      # TODO: Once uploads are using the progress store, refactor the file
      # processing code out of the handler, as once finish() is called,
      # then we've "handled" the request.
      self.finish()

      self.total_size = os.path.getsize(surrogate_file)
      self.application.progress_store.update_current_file_size(
         self.file_id, self.total_size)

      # SHA256 will create a fixed length basename for the file
      local_filename = os.path.join(
         storage_dir, hashlib.sha256(suggested_filename).hexdigest())

      # Copy the file out of the surrogate Downloads directory into the
      # file-server file manager directory
      # TODO: SV-2569 Once this completes, the surrogate can delete the
      # downloaded file from the surrogate Downloads directory as it is no
      # longer needed.
      yield self.application.executor.submit(
         shutil.copy, surrogate_file, local_filename)

      self.application.progress_store.update_file_path(
         self.file_id, local_filename)

      if self._is_isolated_docview_download():
         # This case is for the original document or safe document
         # being downloaded in the isolated safedocs viewer when
         # that's allowed in the download policy.
         # The original file went through the file-server already
         # to be posted to Safedocs, so we just allow it to avoid
         # triggering recursive file download or Safedocs.
         self.application.progress_store.set_file_processing(self.file_id)
         self.application.progress_store.set_file_allow(self.file_id)
         return

      # Locate & verify the proxy categorization result passed from the ICAP.
      proxy_category_result = None
      if metadata.get('proxy_category'):
         icap_response = (policy_map.get(metadata['key'], {}).get(
            'icap_proxy_category_response'))
         if not icap_response:
            proxy_category_result = {'status': 'failed', 'category': None}
            self.log.warning({'local_filename': local_filename,
                              'suggested_filename': suggested_filename,
                              'id': self._req_params['download_id'],
                              'key': metadata.get('key')},
                             event='icap-proxy-category-response-not-found')
         elif not self._verify_icap_response(icap_response, metadata):
            proxy_category_result = {'status': 'failed', 'category': None}
            self.log.warning({'local_filename': local_filename,
                              'suggested_filename': suggested_filename,
                              'id': self._req_params['download_id'],
                              'key': metadata.get('key'),
                              'icap_xhr_url': icap_response.get('xhr_url'),
                              'icap_user_id': icap_response.get('user_id'),
                              'icap_tenant_id': icap_response.get(
                                 'tenant_id')},
                             event='icap-proxy-category-verification-failed')
            # FIXME: Should this be block, or display an appropriate modal?
            self.application.progress_store.set_file_error(self.file_id)
            return
         else:
            proxy_category_result = icap_response.get('result')

      self.log.info({'local_filename': local_filename,
                     'suggested_filename': suggested_filename,
                     'file_id': self.file_id},
                    event='file-entered-fileserver', opslog=False)

      # Split the file extension and pass to get_file_type_from_file
      file_type, mime_type = get_file_type_from_file(
         local_filename, os.path.splitext(suggested_filename)[1])
      self._req_params['file_type'] = file_type
      self._req_params['mime_type'] = mime_type

      self.log.increment('file-download-type-%s' % file_type)
      self.log.increment('file-download')
      self.log.increment('file-download-surrogate')

      # Get the file policy from pnr-enforcement
      policy, session_id = yield get_pnr_policy(
         self._req_params, self.get_current_user(), self.request,
         local_filename, suggested_filename, file_type, self.log,
         proxy_category_result)

      if not policy:
         # Policy server not available...
         if can_safedocs(file_type):
            # ...but safedoc-able file, so send to safedocs and scan
            policy, session_id = (SAFEDOC, None)
         elif file_type in PASSWORD_PROMPT_CANDIDATE:
            # encrypted archives should also be scanned without policy
            policy, session_id = (ALLOW, 'null')
         else:
            # ...all other files. Fail open.
            self.application.progress_store.set_file_processing(self.file_id)
            self.application.progress_store.set_file_allow(self.file_id)
            return
      yield self.process_file(policy, session_id,
                              local_filename, suggested_filename)
      time_taken = monotonic() - start_time
      self.log.timer('file-process-time', time_taken)

   def on_auth_success(self):
      """Start to handle request for tc_processing.

      This is the entry point of the request in file-server from the TC, sent
      after the surrogate has downloaded the file and has notified the TC.
      Starts the request processing coroutine and adds its future to the
      ioloop.
      """
      if not self.enforce_request_completness(
            query_keys={'rid'}, body_keys={'download_id'}):
         raise self.badrequest('Invalid API request')

      tornado.ioloop.IOLoop.instance().add_future(
         self.handle_download_request(), self.handle_request_exception_handler)


class DropFileHandler(DownloadProcessingMixin, RequestHandler):
   """ Handle a file dropped in via a multi-part form POST.

       The entry point for a file POSTed to safeview as a multipart form. The
       form should contain fields for:
          filename - user readable (original) filename of the file
          content-type - the mime type of the file
          uid - some unique identifier to correlate where this file came from
          version - method used to add the file contents, currently
                    fixed as 1 (base64+rot13)
          content - a textarea field holding the scrambled content.
          from - the original from address from the email

      The file in the 'content' field will be extracted and past into the
      file-server file processing flow (obtain policy, scan/avcheck, etc.)
      and eventually allow download, block or redirect to safedocs. The UX
      displayed is the same as that used for the non-isolated file download
      case (icap) and this relies on the same logic.

      """

   def get_external_safedocs_prefix(self):
      # do not need to use external prefix for drop file as already on the
      # <login host>/dropfile url as a result of the post response.
      return ''

   def unscramble_file_method1(self):
      # Unscramble the file using method 1 - rot13 + base64 decode.

      # The 'file attachment' itself is in a textarea field called
      # 'content' which is base64 encoded then rot13 scrambled.
      try:
         return b64decode(encode(self.metadata.get('content')[0], 'rot13'))
      except Exception as ex:
         log.info({'error': ex},
                  event='dropfile-unscramble-failed')

   def save_file_to_disk(self):
      # Save the file content to disk at the specified location
      with open(self.local_filename, 'wb') as dropped_file:
         dropped_file.write(self.content)

   def _set_csp(self):
      """Set the CSP for the POST response (the interstatial page.).

      CSP will disallow all but style and scripts being loaded from the
      same origin, and prevent inline scripts. The interstatial page
      contains a link to css and js and an iframe.
      """
      cluster_host = self.domain_scheme.get_cluster_host()
      xhr_cluster_host = self.domain_scheme.get_cluster_host(('xhr', 0))
      login_host = self.domain_scheme.get_login_host()
      csp = ("default-src 'none'; "
             "script-src 'self' https://%(safeview_static)s; "
             "style-src 'self' https://%(safeview_static)s; "
             "img-src 'self' data: https://%(safeview_static)s; "
             "frame-src 'self' https://%(cookied_domains)s; "
             "connect-src 'self' %(cookied_domains)s; "
             "report-uri /safeview-client-logger/csp-violation;"
             % {'safeview_static': cluster_host,
                'cookied_domains': ' '.join(
                  ['https://' + d for d in
                   [xhr_cluster_host, cluster_host, login_host]])})

      self.set_header('Content-Security-Policy', csp)

   # pylint: disable=too-many-statements
   @tornado.gen.coroutine
   def handle_download_request(self):
      # Decode multi-part form posted to extract metadata and files
      self.content = None

      start_time = monotonic()
      self.metadata = self.request.body_arguments

      # Default the optional fields
      if not self.metadata.get('uid'):
         self.metadata['uid'] = ['']
      if not self.metadata.get('version'):
         self.metadata['version'] = ['1']

      node_id = config.get('instance-metadata', 'node_id')
      log_data = {'file_name': 'unknown',
                  'content_type': 'unknown',
                  'dropfile_uid': self.metadata.get('uid')[0],
                  'version': self.metadata.get('version')[0],
                  'node_id': node_id}

      if not self.application.space_available():
         # Not enough space remaining.
         self.log.warning(log_data,
                          event='inbound-insufficient-disk-space')
         raise tornado.web.HTTPError(status_code=503)

      # Scramble Method 0 - base64 file in 'file' attribute
      # This is for implementing a file browse + isolate (for testing)
      if self.metadata.get('version')[0] == '0':
         self.content = self.request.files['file'][0].body
         self._req_params['file_name'] = self.request.files['file'][0].filename
         self._req_params['content-type'] = (
            self.request.files['file'][0].content_type)

      # Scramble Method 1 - base64 rot13 in textarea field
      # Used by safemail attachment wrapping
      elif self.metadata.get('version')[0] == '1':
         self.content = yield self.application.executor.submit(
            self.unscramble_file_method1)
         self._req_params['file_name'] = self.metadata.get('filename')[0]
         self._req_params['content-type'] = self.metadata.get('content-type')[0]
      else:
         self.log.warning(log_data,
                          event='dropfile-unknown-version')
         raise tornado.web.HTTPError(status_code=400)

      self.dropfile_uid = self.metadata.get('uid')[0] # To go into Druid later...
      log_data['file_name'] = self._req_params['file_name']
      log_data['content_type'] = self._req_params['file_name']

      # Free the form metadata and files objects ASAP as they could be huge
      # TODO: In the future we should look into implementing our own form handler
      # that can stream out the content straight to disk instead.
      del self.metadata
      self.request.body_arguments['content'] = []
      self.request.body_arguments = []
      self.request.arguments = []
      self.request.files = {}

      if not self.content:
         self.log.warning(log_data,
                          event='dropfile-invalid-content')
         raise tornado.web.HTTPError(status_code=400)
      self._req_params['file_size'] = len(self.content)

      if int(self._req_params['file_size']) > config.getint(
            'file-server', 'max_file_download_size'):
         self.log.warning(log_data,
                          event='dropfile-too-big')
         raise tornado.web.HTTPError(status_code=413)

      # Create entry in the progress_store. A storage directory for the
      # lifetime of the file is also created by this insertion.
      file_id = self.application.progress_store.insert_file_icap(
         self._req_params['file_name'],
         self._req_params['user_id'], self._req_params['tenant_id'],
         self._req_params['file_size'])

      # Create the single_use_code - don't log it!
      code = self.application.progress_store.create_single_use_code(file_id)

      log_data['file_id'] = file_id
      self.log.info(log_data, event='dropfile-transfer-inbound')

      # Serve the template
      FILE_SERVER_IFRAME_URL = (
         'https://%s/safeview-fileserv/dl_status?cid=%s_&a=%s&b=%s')
      cluster_host = self.domain_scheme.get_cluster_host()
      self._disable_client_caching()
      self._set_csp()
      self.render(
         www('templates/dropfile.template'),
         file_name=self._req_params['file_name'],
         iframe_url = FILE_SERVER_IFRAME_URL % (
            cluster_host, node_id, file_id, code))

      # Write the file from memory to disk in a separate thread, then free the
      # memory being used for this.
      self.local_filename = os.path.join(
         self.application.progress_store.get_file_storage_dir(file_id),
         'file')

      yield self.application.executor.submit(
         self.save_file_to_disk)
      del self.content

      self.application.progress_store.set_file_pending(file_id)
      self.application.progress_store.update_file_path(file_id,
                                                       self.local_filename)

      # Start processing the file through the main file processing logic
      # as per the non-isolated (icap) route.
      self.file_id = file_id
      self.docid = None
      # FIXME Use the domain from the 'from:' address?
      self.src_uri = 'https://menlosecurity.com/mail/' + self.dropfile_uid

      self.total_size = self._req_params['file_size']
      self.application.progress_store.update_current_file_size(
         self.file_id, self.total_size)

      self.log.info({'local_filename': self.local_filename,
                     'suggested_filename': self._req_params['file_name'],
                     'file_id': self.file_id,
                     'file_size': self.total_size},
                    event='file-entered-fileserver')

      # Split the file extension and pass to get_file_type_from_file
      file_type, mime_type = get_file_type_from_file(
         self.local_filename,
         os.path.splitext(self._req_params['file_name'])[1])
      self._req_params['file_type'] = file_type
      self._req_params['mime_type'] = mime_type
      self._req_params['src_uri'] = self.src_uri

      self.log.increment('file-download-type-%s' % file_type)
      self.log.increment('file-download')
      self.log.increment('file-download-dropfile')

      self.application.progress_store.set_original_headers(
         self.file_id, {'content-type':[self._req_params['content-type']]})

      # Get the file policy from pnr-enforcement
      policy, session_id = yield get_pnr_policy(
         self._req_params, self.get_current_user(), self.request,
         self.local_filename, self._req_params['file_name'], file_type,
         self.log, None)

      if not policy:
         # Policy server not available...
         if can_safedocs(file_type):
            # ...but safedoc-able file, so send to safedocs and scan
            policy, session_id = (SAFEDOC, None)
         elif file_type in PASSWORD_PROMPT_CANDIDATE:
            # encrypted archives should also be scanned without policy
            policy, session_id = (ALLOW, 'null')
         else:
            # ...all other files. Fail open.
            self.application.progress_store.set_file_processing(self.file_id)
            self.application.progress_store.set_file_allow(self.file_id)
            return
      yield self.process_file(policy, session_id,
                              self.local_filename,
                              self._req_params['file_name'])

      time_taken = monotonic() - start_time
      self.log.timer('file-process-time', time_taken)


   def redirect_to_login_page(self, query=None):
      # Render a page containing an autosubmit form which performs a login
      # action or renders the login screen.
      cluster_host = self.domain_scheme.get_cluster_host()
      xhr_cluster_host = self.domain_scheme.get_cluster_host(('xhr', 0))
      login_host = self.domain_scheme.get_login_host()
      redirect_url = ('https://%s/dropfile?%s' % (login_host, query) if query
                      else 'https://%s/dropfile' % (login_host))
      self._disable_client_caching()
      self.render(www('templates/dropfile-auth.template'),
                  login_url='https://%s/account/login?form' % (login_host),
                  redirect_url=redirect_url,
                  cookied_domains='%s,%s,%s,%s' % (
                                  self.request.host, xhr_cluster_host,
                                  cluster_host, login_host))

   @tornado.web.asynchronous
   def post(self):
      self._req_params = {}

      user_info = self.get_current_user()
      if not user_info:
         # Redirect to login page by rendering a protected page
         self.log.warning({},
                          event='dropfile-not-authenticated')
         self.redirect_to_login_page()
         return

      self._req_params['user_id'] = user_info['uid']
      self._req_params['tenant_id'] = user_info['tid']

      tornado.ioloop.IOLoop.instance().add_future(
         self.handle_download_request(), self.handle_request_exception_handler)

   @tornado.web.asynchronous
   def get(self):

      user_info = self.get_current_user()
      if not user_info:
         # Redirect to login page by rendering a protected page
         self.log.warning({},
                          event='dropfile-not-authenticated-get')
         self.redirect_to_login_page(self.request.query)
         return

      file_browse = self.get_query_argument('browse', default='false')

      self.log.info({}, event='dropfile-get-request')

      # Serve the template
      self._disable_client_caching()
      self._set_csp()
      self.render(www('templates/dropfile-get.template' if file_browse
                      else 'templates/dropfile-browse.template'))

class ProxyCategoryHandler(RequestHandler):
   """Handle downstream categorization verficiation requests
      (usually sent from PNR-ICAP)"""
   # FIXME (JIRA-2893): Need a mechanism to allow only PNR-ICAP to
   # access this handler.
   def post(self):
      data = json.loads(self.request.body)
      update_policy_map(data['key'], {
         'result': data['result'],
         'xhr_url': data['xhr_url'],
         'user_id': data['user_id'],
         'tenant_id': data['tenant_id']
      })
      self.write({'ok': True})
      self.finish()


class KeepAliveHandler(RequestHandler):
   """Refresh expire timer of process_store"""
   @tornado.gen.coroutine
   def get(self, file_id):
      """Refresh progress_store for the file_id"""
      # pylint: disable=arguments-differ
      self.log.debug({'file_id': file_id}, event='download-file-keep-alive')
      self.application.progress_store.refresh_file_id(file_id)
      self.finish()


class FileServerApp(SafelyApplication):
   def __init__(self, *args, **kwargs):
      super(FileServerApp, self).__init__(*args, **kwargs)
      self.progress_store = ProgressStore()
      self.executor = concurrent.futures.ThreadPoolExecutor(4)

      # Set the check for file_ids not progressing to 'pending'
      self._inbound_check_timer = tornado.ioloop.PeriodicCallback(
         self._inbound_check,
         config.getint('file-server', 'background_check_interval') * 1000)
      self._inbound_check_timer.start()

      # Set the garbage collector for out of date file_ids
      self._download_gc_timer = tornado.ioloop.PeriodicCallback(
         self._download_gc,
         config.getint('file-server', 'background_check_interval') * 1000)
      self._download_gc_timer.start()

   def _inbound_check(self):
      """Check for downloads that have been initiated by ICAP but not sent.

      In the event an error occurs between the ICAP server notifying a file
      is on its way and starting the transfer, this check will move any
      stuck INBOUND downloads into ERROR so the UI is updated.
      """
      for file_id in self.progress_store.get_stale_inbound_file_ids(
            config.getint('file-server', 'max_inbound_interval')):
         log.info({'file_id': file_id},
                  event='inbound-check-transition-to-error')
         log.increment('file-store-inbound-errors')
         self.progress_store.set_file_error(file_id)

   def _download_gc(self):
      """Clean up any progress_store entries and storage_dirs for stale file_ids.

      Three grace periods exist before the file is cleaned up.
         1. 'max_ping_interval' - If the duration since the most recent
            access_time of the file exceeds this value. The TC/download page
            will continually refesh access_time, so the grace period allows the
            client to lose connection and restore it again before the file is
            deleted.
         2. 'max_retain_interval' - If the duration since the most recent
            state_change_time of the file exceeds this value. When the file
            has completed processing, the file will be removed after this
            duration to prevent a user leaving the download page open and
            tying up resources.
         3. 'download_grace_interval' - If the duration since the first
            attempted download of the file exceeds this value. When the
            file-server detects a file download has been requested, it will
            record the time, and remove the file after this interval so
            that clean up will happen sooner. The interval allows the download
            to be restarted by the user for a short duration after the first
            download.
      """
      file_count = self.progress_store.get_file_count()
      log.gauge('file-store-count', file_count)

      for file_id in self.progress_store.get_stale_file_ids(
            config.getint('file-server', 'max_ping_interval'),
            config.getint('file-server', 'max_retain_interval'),
            config.getint('file-server', 'download_grace_interval')):
         log.debug({'file_id': file_id},
                  event='cleanup-file-id')
         self.progress_store.remove_file_id(file_id)

   def space_available(self):
      """Return whether there is space remaining to save files to."""
      directory = config.get('file-server', 'file_dir')

      # Check percentage free
      return safly.os_util.get_free_disk_percent(directory) >= config.getint(
         'file-server', 'free_disk_threshold')


class FileServer(SafelyTornadoApp):
   def __super(self):
      return super(FileServer, self)

   NAME = 'file-server'
   DOWNLOAD_HANDLERS = [
      ###### For external use (hence 'safeview-fileserv' prefix).
      # Hack for Google Chrome: when chrome fails to decode the suggested
      # filename in the content-disposition header, it uses the
      # @download_id as the suggested filename. Adding a slash after
      # the @download_id will cause the filename to be "download" instead
      # of the @download_id
      (r"/safeview-fileserv/proxy_category_response", ProxyCategoryHandler),
      (r"/safeview-fileserv/tc_status", TCStatusHandler),
      (r"/safeview-fileserv/dl_status", DLPageStatusHandler),
      (r"/safeview-fileserv/tc_processing", TCProcessingHandler),
      (r"/safeview-fileserv/tc_download/(.+)/", DownloadHandler),
      (r"/safeview-fileserv/icap_status/(.+)/", ICAPStatusHandler),
      (r"/safeview-fileserv/icap_download/(.+)/", DownloadHandler),
      # TODO: Due to the proxy being outside of the trusted internal HAProxy
      # routes, these handlers are only used internally, but should be removed
      # from the external HAProxy routing when possible.
      (r"/safeview-fileserv-routing/icap_file_request", ICAPInboundHandler),
      (r"/safeview-fileserv/icap_file_transfer", ICAPTransferHandler),
      (r"/safeview-fileserv/icap_retrieval/(.+)/", ICAPDownloadHandler),
      (r"/safeview-fileserv/archive_download/(.+)/(.+)", ArchDownloadHandler),
      (r"/safeview-fileserv/keepalive/(.+)", KeepAliveHandler),
      (r"/dropfile", DropFileHandler)
   ]
   UPLOAD_HANDLERS = [
      ###### For internal use between Surrogate and File-server.
      (r"/surrogate_status", SurrogateStatusHandler),
      (r"/surrogate_processing", SurrogateProcessingHandler),
   ]

   def __init__(self, *args, **kwargs):
      super(FileServer, self).__init__(*args, **kwargs)
      tornado.locale.load_translations(
         os.path.join(os.path.dirname(__file__), "locale"))
      tornado.locale.set_default_locale('en')

   def setup_arg_parser(self):
      parser = SafelyTornadoApp.setup_arg_parser(self)
      parser.add_argument(
         '--download-home',
         default="/home/surrogate/Downloads",
         help="""Location of download directory within the surrogate chroot
                 filesystem (i.e., must be valid to the surrogate).""")
      return parser

   def pre_run_init(self):
      self.__super().pre_run_init()
      _globals.args = self.args
      clean_download_directory()
      # This instance will use tornado.ioloop.current(instance=False) by
      # default.
      self._inotify_source = safly.inotify.InotifySourceIOLoop()
      # Get the application object, validating that it's of the right type.
      # Initialize and start the plugin manager for the service-level plugins.
      self._plugin_manager_svc_kwargs = {
            'config': config,
            # This is the config section for the program
            # loading/instantiating/controlling the plugins.
            'config_section_program': self.NAME,
            # For now, use an executor that is exclusive to (and shared
            # amongst all) the plugins.
            # Then, some time later, we could rationalize those into groups
            # (one for CPU-intensive calculations, another for blocking
            # generic I/O calls (like file access), etc.).
            'executor': concurrent.futures.ThreadPoolExecutor(2),
            # This is an inotify "source" that is made available to plugins,
            # but that is owned by this class.
            'inotify_source': self._inotify_source,
            # The contents of this dictionary is not known to this instance,
            # but the dictionary instance itself is manipulated across all
            # plugin calls.
            'plugin_shared_config': {},
            }
      self._plugin_manager_svc = safly.plugin_manager.PluginManager()
      # Start the asynchronous part of this function now, and let the ioloop
      # drive that to conclusion.
      self.io_loop.add_future(
            self.__pre_run_init_post_cr(),
            callback=self.stop_ioloop_on_future_exception)

   @tornado.gen.coroutine
   def __pre_run_init_post_cr(self):
      yield tornado.gen.maybe_future(
            self._plugin_manager_svc.start(
               plugin_list=plugins_service.PLUGIN_MANAGER_LIST_ALL,
               initialize_kwargs=self._plugin_manager_svc_kwargs,
               on_start_kwargs=self._plugin_manager_svc_kwargs,
               on_stop_kwargs=self._plugin_manager_svc_kwargs,
               # For now, we will tollerate errors in the plugins, and carry on.
               keep_going_on_start=True))

   # NOTE: callers of _clean_exit() expect this function to never return.
   def _clean_exit(self, err):
      def _clean_exit_2(future=None):
         # We don't need the "inotify source" from this point on.
         self._inotify_source.close()

      # Conditionally (if the plugin manager handling those exists) stop the
      # service-level plugins.
      if getattr(self, '_plugin_manager_svc', None):
         # We want this to execute after all the other initializations and
         # pending work have finished executing: this will give
         # '__pre_run_init_post_cr()' a chance to complete before
         # 'PluginManager.stop()' runs.
         self.io_loop.add_callback(
               lambda: self.io_loop.add_future(
                  tornado.gen.maybe_future(
                     self._plugin_manager_svc.stop(
                        on_stop_kwargs=self._plugin_manager_svc_kwargs)),
                     callback=_clean_exit_2))
      else:
         _clean_exit_2()
      # Signal ioloop termination and wait for it to finish, then exit the
      # program.
      self.__super()._clean_exit(err)

   def create_tornado_app(self):
      app = FileServerApp([], debug=False, gzip=True,
                          # Tornado calls get_current_user  on error
                          # path (i.e, write_error()) for some reason.
                          need_secret=True)

      # Any requests from the surrogates will match 'upload_if' and be passed
      # here to the UPLOAD_HANDLERS handlers
      upload_if = re.escape(safly.config.get_bind_address("surrogate"))
      app.add_handlers(upload_if, self.UPLOAD_HANDLERS)

      # Add the promiscuous route after. Anything that does not match on the
      # surrogate interface will fall through to download handlers.
      app.add_handlers(r'.*', self.DOWNLOAD_HANDLERS)
      return app


def clean_download_directory():
   """Purge the download directory of old directories and files."""
   try:
      count = 0
      file_dir = config.get('file-server', 'file_dir')
      if os.path.exists(file_dir):
         for file_or_dir in os.listdir(file_dir):
            full_path = os.path.join(file_dir, file_or_dir)
            if os.path.isdir(full_path):
               shutil.rmtree(full_path)
               count += 1
            if os.path.isfile(full_path):
               os.remove(full_path)
               count += 1
      log.info({'items_removed': count},
               event='clean-download-directory')
   except Exception as e:
      log.warn({'error': e},
               event='failed-clean-download-directory')


if __name__ == "__main__":
   server = FileServer(description=__doc__.strip())
   server.run()
