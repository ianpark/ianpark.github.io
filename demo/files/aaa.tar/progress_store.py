"""
The file-server's progress storage implementation.

Each file download passing through the file-server stores its progress and
state within this object.

Each incoming file creates an entry in the progress store, along with its
own unique file_id. Progress is updated in the progress-store so the
StatusHandlers can request the progress of the transfer for their client.

  states:           Proxy / ICAP                          TC
|-----------|
|           |
| inbound   |   ICAP has requested to                     N/A
|           |   send a file to this f-s
|-----------|
|           |
| pending   |   File is being downloaded             File ready in
|           |   from ICAP server                       surrogate
|-----------|
|           |
| processing|                  File is being processed
|           |                  (AVcheck, scanned etc)
|-----------|
|           |                  File is being processed
| safedoc-  |                  (AVcheck, scanned etc)
| processing|               File has been sent to safedocs
|           |               and client should be redirected
|-----------|
|           |                   Processing Complete,
| allow     |                   allow file download
|           |
|-----------|
|           |                   Processing Complete,
| block     |                   Block file download
|           |
|-----------|
|           |
| block_    |  File size too big,                         N/A
| max_size_ |  Block file download
| exceeded  |
|           |
|-----------|
|           |                   Processing Complete,
| safedoc   |               file has been sent to safedocs
|           |              and client should be redirected
|-----------|
|           |
| error     |               Error in file download, retry
|           |
|-----------|

NOTE: The progress_store is NOT threadsafe. Progress store access should ONLY
be performed by the ioloop thread and not from any executor.
"""

import os
import uuid

from safly.logger import get_logger
from safly.timex import monotonic
from utils import create_directory, remove_directory

log = get_logger("file-server-progress-store")


class ProgressStore(object):
   # TODO: UK-1818 / /r/9126/: Replace the usage of these constants with
   # enum-like integers. TC and Chromium will need minor updates, but will
   # ultimately lead to obfuscating the protocol somewhat.

   INBOUND = 'inbound'
   PENDING = 'pending'
   PROCESSING = 'processing'
   SAFEDOC_PROCESSING = 'safedoc_processing'

   ALLOW = 'allow'
   BLOCK = 'block'
   BLOCK_MAX_SIZE = 'block_max_size_exceeded'
   ERROR = 'error'
   SAFEDOC = 'safedoc'
   EXPIRED = 'expired'

   DOWNLOAD = 'download'
   UPLOAD = 'upload'

   def __init__(self, *args, **kwargs):
      super(ProgressStore, self).__init__(*args, **kwargs)
      self._current_downloads = {}

   def _insert_file(self, file_id, metadata):
      """Insert a file transfer into the progress store.

      Metadata dict should contain at least:
      state, file_name, user_id, tenant_id, direction

      state: The current state of the transfer, progressing due to flow above.
      state_change_time: The time at which it last changed state.
      access_time: The time at which the file_id was last accessed. Used to
                   identify stale file_ids.
      first_download_time: The time at which the file was first attempted to be
                           downloaded. Used to identify stale file_ids.
      direction: Indicate if this a file download or upload.
      file_name: Suggested file_name for the file.
      file_path: Full path to the decompressed (if required) original file,
                 either in the surrogate fs, or a temporary file-server
                 directory. Used to copy / link the file for processing, and
                 serve it for when using the download link.
      compressed_file_path: Full path to the compressed version of the original
                            file, if original was received in an encoded form.
                            Used only to serve back to ICAP_server in the event
                            of a native download.
      file_type: The file type (once identified by file introspection, may be
                 None)
      mime_type: The mime type of the file (provided by file introspection, may
                 be None)
      storage_dir: If file is stored in a temporary file-server directory, this
                   is the directory. This is removed when file_id is cleaned up
      current_file_size: Current file size. Used for ICAP download progress.
      expected_file_size: Expected file size. Used for ICAP download progress.
                          Can be None to indicate it is unknown.
      safedocs_url: Safedocs url to redirect to if file has been transferred.
      user_id / tenant_id: User and tenant id of the file.
      original_headers: Original file response headers, used to correctly serve
                        file for download.
      current_stage: The number of the stage (plugin) currently being run
                     (starting at 0).
      number_of_stages: The total number of stages/plugins in the list to be
                        run for the current file.
      """
      assert file_id not in self._current_downloads, 'Dup id: %s' % file_id
      assert metadata.get('state'), 'metadata must contain state'
      assert metadata.get('file_name'), 'metadata must contain file_name'
      assert metadata.get('user_id'), 'metadata must contain user_id'
      assert metadata.get('tenant_id'), 'metadata must contain tenant_id'
      assert metadata.get('direction'), 'metadata must contain direction'

      t = monotonic()
      file_entry = {
         'state': None,
         'state_change_time': t,
         'access_time': t,
         'first_download_time': None,
         'direction': None,
         'file_name': None,
         'file_path': None,
         'compressed_file_path': None,
         'file_type': None,
         'mime_type': None,
         'storage_dir': None,
         'current_file_size': 0,
         'expected_file_size': 0,
         'safedocs_url': None,
         'user_id': None,
         'tenant_id': None,
         'single_use_code': None,
         'original_headers': {},
         'current_stage': 0,
         'number_of_stages': 1,
         'src_uri': '',
         'analytics': {},
      }
      file_entry.update(metadata)
      self._current_downloads[file_id] = file_entry

   def insert_file_icap(self, file_name, user_id, tenant_id, file_size):
      """Insert a file transfered from icap_server into the progress store.

      A file from icap_server will enter at state inbound, with a storage_dir.
      """
      file_id = str(uuid.uuid4())

      # Create a storage directory for the lifetime of the file.
      storage_dir = create_directory('%s' % file_id)

      self._insert_file(file_id, {
         'state': self.INBOUND,
         'file_name': file_name,
         'user_id': user_id,
         'tenant_id': tenant_id,
         'expected_file_size': file_size,
         'direction': self.DOWNLOAD,
         'storage_dir': storage_dir})
      return file_id

   def insert_file_tc(self, file_id, file_name, user_id, tenant_id,
                      storage_dir, direction):
      """Insert a file from the surrogate into the progress store.

      A file from the surrogate will enter at state pending.
      """
      self._insert_file(file_id, {
         'state': self.PENDING,
         'file_name': file_name,
         'user_id': user_id,
         'tenant_id': tenant_id,
         'file_size': None,
         'direction': direction,
         'storage_dir': storage_dir})

   def remove_file_id(self, file_id):
      """Removes a file from the progress store."""
      # Cleanup storage_dir
      storage_dir = None
      try:
         storage_dir = self._current_downloads[file_id]['storage_dir']
         if storage_dir:
            remove_directory(storage_dir)
      except KeyError as err:
         log.info({'storage_dir': storage_dir,
                   'error': '%s: %s' % (type(err).__name__, err),
                   'file_id': file_id},
                  event='remove_file_id')
      except Exception as ex:
         # Don't fail if the file_id or storage_dir itself does not exist.
         log.error({'storage_dir': storage_dir,
                    'error': '%s: %s' % (type(ex).__name__, ex),
                    'file_id': file_id},
                   event='remove_file_id')

      # Remove from the progress store
      self._current_downloads.pop(file_id, None)

   def refresh_file_id(self, file_id):
      self._update_access_file_id(file_id)

   def _update_access_file_id(self, file_id, access_time=None):
      """Update the file_id access time."""
      if file_id in self._current_downloads:
         self._current_downloads[file_id]['access_time'] = (
            access_time or monotonic())

   def _update_state_change(self, file_id):
      """Update the file_id's state_change_time."""
      change_time = monotonic()
      self._update_access_file_id(file_id, change_time)
      self._current_downloads[file_id]['state_change_time'] = change_time

   def _update_file_state(self, file_id, state):
      """Update the file_id's state."""
      log.debug({'file_id': file_id,
                 'from': self._current_downloads[file_id]['state'],
                 'to': state},
                event='file-id-state-change')
      self._update_state_change(file_id)
      self._current_downloads[file_id]['state'] = state

   def create_single_use_code(self, file_id):
      """Create and set a file's single use download code, and return it."""
      self._update_access_file_id(file_id)
      # Create a 256bit / 32byte secret
      code = os.urandom(32).encode('hex')
      self._current_downloads[file_id]['single_use_code'] = code
      return code

   def check_single_use_code(self, file_id, code):
      """Check and remove a file's single use code.

      Destroy the single use code even if a verification fails to prevent abuse
      """
      if file_id not in self._current_downloads:
         return False
      self._update_access_file_id(file_id)
      res = False
      if self._current_downloads[file_id]['single_use_code']:
         res = code == self._current_downloads[file_id]['single_use_code']
         self._current_downloads[file_id]['single_use_code'] = None
      return res

   def set_file_pending(self, file_id):
      """Move file_id into pending state."""
      assert self._current_downloads[file_id]['state'] == self.INBOUND
      self._update_file_state(file_id, self.PENDING)

   def set_file_processing(self, file_id):
      """Move file_id into processing state."""
      assert self._current_downloads[file_id]['state'] == self.PENDING
      self._update_file_state(file_id, self.PROCESSING)

   def set_file_safedoc_processing(self, file_id, safedocs_url):
      """Move file_id into safedoc_processing state."""
      assert (self._current_downloads[file_id]['state'] in
              [self.PROCESSING, self.PENDING])
      self._update_file_state(file_id, self.SAFEDOC_PROCESSING)
      self._current_downloads[file_id]['safedocs_url'] = safedocs_url

   def set_file_allow(self, file_id):
      """Move file_id into allow state."""
      assert self._current_downloads[file_id]['state'] == self.PROCESSING
      self._update_file_state(file_id, self.ALLOW)

   def set_file_block(self, file_id):
      """Move file_id into block state."""
      assert (self._current_downloads[file_id]['state'] in
              [self.PROCESSING, self.BLOCK])
      self._update_file_state(file_id, self.BLOCK)

   def set_file_block_max_size_exceeded(self, file_id):
      """Move file_id into block_max_size_exceeded state."""
      assert self._current_downloads[file_id]['state'] == self.PENDING
      self._update_file_state(file_id, self.BLOCK_MAX_SIZE)

   def set_file_safedoc(self, file_id):
      """Move file_id into safedoc state."""
      assert (self._current_downloads[file_id]['state'] ==
              self.SAFEDOC_PROCESSING)
      self._update_file_state(file_id, self.SAFEDOC)

   def set_file_error(self, file_id):
      """Move file_id into error state."""
      try:
         self._update_file_state(file_id, self.ERROR)
      except Exception as ex:
         # Don't fail if setting the error state failed.
         log.error({'file_id': file_id,
                    'error': '%s: %s' % (type(ex).__name__, ex)},
                   event='set-file-error')

   def set_original_headers(self, file_id, headers):
      """Set the dictionary containing the original file request's headers."""
      assert isinstance(headers, dict)
      self._update_access_file_id(file_id)
      self._current_downloads[file_id]['original_headers'] = headers

   def set_first_file_download_time(self, file_id):
      """Set time the file was first downloaded. If already set, do nothing."""
      if not self._current_downloads[file_id]['first_download_time']:
         self._current_downloads[file_id]['first_download_time'] = monotonic()

   def set_file_type(self, file_id, file_type, mime_type):
      """Set file type for the given file."""
      self._update_access_file_id(file_id)
      self._current_downloads[file_id]['file_type'] = file_type
      self._current_downloads[file_id]['mime_type'] = mime_type

   def set_encryption_detail(self, file_id, enc_detail):
      self._update_access_file_id(file_id)
      self._current_downloads[file_id]['enc_detail'] = enc_detail

   def set_src_uri(self, file_id, src_uri):
      self._update_access_file_id(file_id)
      self._current_downloads[file_id]['src_uri'] = src_uri

   def set_analytics(self, file_id, analytics):
      self._update_access_file_id(file_id)
      self._current_downloads[file_id]['analytics'] = analytics

   def update_file_path(self, file_id, file_path):
      """Update the file path to the file_id."""
      self._update_access_file_id(file_id)
      self._current_downloads[file_id]['file_path'] = file_path

   def update_compressed_file_path(self, file_id, file_path):
      """Update the file path the compressed version of the file_id."""
      self._update_access_file_id(file_id)
      self._current_downloads[file_id]['compressed_file_path'] = file_path

   def update_current_file_size(self, file_id, file_size):
      """Update the current file size of the file_id."""
      self._update_access_file_id(file_id)
      self._current_downloads[file_id]['current_file_size'] = file_size

   def update_plugin_stage(self, file_id, stage, number_of_stages):
      """Update the stage through the plugin list and/or total stages."""
      self._update_access_file_id(file_id)
      self._current_downloads[file_id]['current_stage'] = stage
      self._current_downloads[file_id]['number_of_stages'] = number_of_stages

   def check_exists_and_inbound(self, file_id):
      """Check if file_id exists in the progress store and in state INBOUND"""
      return (file_id in self._current_downloads and
              self._current_downloads[file_id]['state'] == self.INBOUND)

   def get_user_id(self, file_id):
      """Return the user id for the file_id."""
      return self._current_downloads[file_id]['user_id']

   def get_tenant_id(self, file_id):
      """Return the tenant id for the file_id."""
      return self._current_downloads[file_id]['tenant_id']

   def get_file_direction(self, file_id):
      """Return the direction of the file transfer."""
      self._update_access_file_id(file_id)
      return self._current_downloads[file_id]['direction']

   def get_file_state(self, file_id):
      """Return the file_id's state or EXPIRED if it does not exist."""
      if file_id in self._current_downloads:
         self._update_access_file_id(file_id)
         return self._current_downloads[file_id]['state']
      log.info({'file_id': file_id}, event='file-id-not-found')
      return self.EXPIRED

   def get_file_safedocs_url(self, file_id):
      """Return the file_id's safedocs_url."""
      self._update_access_file_id(file_id)
      return self._current_downloads[file_id]['safedocs_url']

   def get_file_type(self, file_id):
      """Return the file type for the given file."""
      self._update_access_file_id(file_id)
      return (self._current_downloads[file_id]['file_type'],
              self._current_downloads[file_id]['mime_type'])

   def get_encryption_detail(self, file_id):
      """Return the encryption detail structure."""
      self._update_access_file_id(file_id)
      return self._current_downloads[file_id].get('enc_detail', {})

   def get_file_storage_dir(self, file_id):
      """Return the file_id's storage_dir."""
      self._update_access_file_id(file_id)
      return self._current_downloads[file_id]['storage_dir']

   def get_file_path_and_name(self, file_id, compressed=False):
      """Return the file_path and file_name for the file_id.

      If compressed is True, function will attempt to return
      compressed_file_path if one exists.
      """
      self._update_access_file_id(file_id)
      if compressed:
         file_path = (
            self._current_downloads[file_id]['compressed_file_path'] or
            self._current_downloads[file_id]['file_path'])
      else:
         file_path = self._current_downloads[file_id]['file_path']

      return (file_path, self._current_downloads[file_id]['file_name'])

   def get_download_file_sizes(self, file_id):
      """Return the current downloaded file size and its expected size."""
      return (self._current_downloads[file_id]['current_file_size'],
              self._current_downloads[file_id]['expected_file_size'])

   def get_file_analysis_stage(self, file_id):
      """Return the file's current analysis stage through the plugins.

      Returns the number of the plugin currently being used and the total
      number of plugins in the list.
      """
      log.debug({'current_stage': self._current_downloads[file_id]['current_stage'],
                'number_of_stages': self._current_downloads[file_id]['number_of_stages']},
                event='get_file_analysis_stage')
      return (self._current_downloads[file_id]['current_stage'],
              self._current_downloads[file_id]['number_of_stages'])

   def get_original_headers(self, file_id):
      """Return the dictionary containing the original file request's headers.
      """
      self._update_access_file_id(file_id)
      return self._current_downloads[file_id]['original_headers']

   def get_file_count(self):
      """Return the number of files currently in the progress store."""
      return len(self._current_downloads)

   def get_src_uri(self, file_id):
      """Return the original src_uri of the file_id."""
      self._update_access_file_id(file_id)
      return self._current_downloads[file_id]['src_uri']

   def get_analytics(self, file_id):
      """Return the PNR analytics of the file_id."""
      self._update_access_file_id(file_id)
      return self._current_downloads[file_id]['analytics']

   def get_stale_file_ids(self, access_time_secs, state_change_time_secs,
                          first_download_time_sec):
      """Return a list of stale file_ids.

      File_ids are only considered stale if they are in states ALLOW, BLOCK,
      BLOCK_MAX_SIZE, ERROR or SAFEDOC.

      A stale file_id has an access_time older than access_time_secs, a
      state_change_time older than state_change_time_secs, or a
      first_download_time older than first_download_time_sec.

      If a download_page exists for a file, it will continually send status
      requests to keep the file alive, however once a file download has been
      initiated, the duration to keep the file alive for is truncated.
      """
      assert isinstance(access_time_secs, int)
      assert isinstance(state_change_time_secs, int)
      access_cut_off = monotonic() - access_time_secs
      state_change_cut_off = monotonic() - state_change_time_secs
      download_cut_off = monotonic() - first_download_time_sec
      stale = []
      for file_id in self._current_downloads:
         if self._current_downloads[file_id]['state'] not in [
               self.ALLOW, self.BLOCK, self.BLOCK_MAX_SIZE, self.ERROR,
               self.SAFEDOC]:
            continue

         if (self._current_downloads[file_id]['access_time'] <
             access_cut_off):
            stale.append(file_id)
         elif (self._current_downloads[file_id]['state_change_time'] <
               state_change_cut_off):
            stale.append(file_id)
         elif (self._current_downloads[file_id]['first_download_time'] and
               self._current_downloads[file_id]['first_download_time'] <
               download_cut_off):
            # Need to test it has been downloaded at least once
            stale.append(file_id)

      log.debug({'stale_file_ids': stale},
                event='get-stale-file_ids')
      return stale

   def get_stale_inbound_file_ids(self, older_than_secs):
      """Return stale file_ids in INBOUND state.

      Returns a list of INBOUND state file_ids, with a state_change_time older
      than older_than_secs.
      """
      assert isinstance(older_than_secs, int)
      cut_off = monotonic() - older_than_secs
      stale = []
      for file_id in self._current_downloads:
         if (self._current_downloads[file_id]['state'] == self.INBOUND
             and self._current_downloads[file_id]['state_change_time']
             < cut_off):
            stale.append(file_id)

      log.debug({'stale_file_ids': stale},
                event='get-stale-inbound-file_ids')
      return stale

   def is_download(self, file_id):
      """Test if an entry is a DOWNLOAD"""
      return self.get_file_direction(file_id) == self.DOWNLOAD
